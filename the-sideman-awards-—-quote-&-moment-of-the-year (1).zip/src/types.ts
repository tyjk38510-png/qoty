export type AwardCategory =
  | 'quote_of_the_year'
  | 'sideman_of_the_year'
  | 'moment_of_the_year'
  | 'funniest_person'
  | 'little_boy_award'
  | 'best_debate'
  | 'honorable_mentions';

export type AwardTier = 'winner' | 'nominee' | 'honorable_mention';

export interface AwardEntry {
  id: string;
  category: AwardCategory;
  tier: AwardTier;
  nomineeName: string;
  signatureThing: string;
  quote: string;
  title: string;
  context: string;
  episode: string;
  year: number;
  imageUrl: string;
  createdAt: string;
  updatedAt: string;
}

export interface AwardEntryInput {
  category: AwardCategory;
  tier: AwardTier;
  nomineeName: string;
  signatureThing: string;
  quote: string;
  title: string;
  context: string;
  episode: string;
  year: number;
  imageUrl: string;
}

export interface CategoryMeta {
  id: AwardCategory;
  label: string;
  shortLabel: string;
  description: string;
  hasWinner: boolean;
  thingLabel: string;
  thingPlaceholder: string;
}

export interface CategoryTheme {
  bandBg: string;
  bandBorder: string;
  headingText: string;
  eyebrowText: string;
  mutedText: string;
  ctaBg: string;
  ctaHover: string;
  cardBorder: string;
  cardHoverBorder: string;
  cardShadow: string;
  cardTitleHover: string;
  laureateBg: string;
  laureateBorder: string;
  laureateAccentText: string;
  thingBoxLight: string;
  thingBoxDark: string;
  thingLabelLight: string;
  thingLabelDark: string;
  tabActiveBg: string;
  swatchDot: string;
}

export const AWARD_CATEGORIES: CategoryMeta[] = [
  {
    id: 'quote_of_the_year',
    label: 'Quote of the Year',
    shortLabel: 'Quote',
    description:
      'The single line delivered with surgical timing that stopped the entire room and lived rent-free all year.',
    hasWinner: true,
    thingLabel: 'Quote Delivery / Their Thing',
    thingPlaceholder: 'e.g. Deadpan justification for a 45-minute wrong turn',
  },
  {
    id: 'sideman_of_the_year',
    label: 'Sideman of the Year',
    shortLabel: 'Sideman',
    description:
      'Honouring the indispensable presence who elevated every episode, carried the banter, and anchored the group.',
    hasWinner: true,
    thingLabel: 'Signature Trait / Their Thing',
    thingPlaceholder: 'e.g. Razor-sharp callbacks & unmatched table chemistry',
  },
  {
    id: 'moment_of_the_year',
    label: 'Moment of the Year',
    shortLabel: 'Moment',
    description:
      'Unscripted chaos, spontaneous storytelling, and collective table laughter that defined the 2026 season.',
    hasWinner: true,
    thingLabel: 'Defining Action / Their Thing',
    thingPlaceholder: 'e.g. Six minutes of live-mic laughter during warm-up',
  },
  {
    id: 'funniest_person',
    label: 'Funniest Person',
    shortLabel: 'Funniest',
    description:
      'Pure comedic consistency—the person who could reduce the whole table to tears with a single glance or throwaway line.',
    hasWinner: true,
    thingLabel: 'Comedy Style / Their Thing',
    thingPlaceholder: 'e.g. Effortless deadpan escalation mid-story',
  },
  {
    id: 'little_boy_award',
    label: 'Little Boy Award',
    shortLabel: 'Little Boy',
    description:
      'Awarded for peak petty stubbornness, dramatic sulking over board game rules, and unfiltered childish energy.',
    hasWinner: true,
    thingLabel: 'Pettiest Habit / Their Thing',
    thingPlaceholder: 'e.g. Refusing to pass the dice after losing one round',
  },
  {
    id: 'best_debate',
    label: 'Best Debate',
    shortLabel: 'Debate',
    description:
      'The heated twenty-minute argument over something completely trivial that divided the room into passionate factions.',
    hasWinner: true,
    thingLabel: 'The Hot Take / Their Thing',
    thingPlaceholder: 'e.g. Arguing cereal is technically a cold breakfast soup',
  },
  {
    id: 'honorable_mentions',
    label: 'Honorable Mentions',
    shortLabel: 'Honorable',
    description:
      'Sharp one-liners, near-misses, and cult-favorite remarks that fell just shy of the podium yet remain unforgettable.',
    hasWinner: false,
    thingLabel: 'Notable Quirk / Their Thing',
    thingPlaceholder: 'e.g. Treating smoke alarms as applause for seasoning',
  },
];

export const CATEGORY_THEMES: Record<AwardCategory, CategoryTheme> = {
  quote_of_the_year: {
    bandBg: 'bg-gradient-to-br from-[#DBEAFE] via-[#EFF6FF] to-[#E0E7FF]',
    bandBorder: 'border-[#93C5FD]',
    headingText: 'text-[#0F1E4A]',
    eyebrowText: 'text-[#1D4ED8]',
    mutedText: 'text-[#1E3A8A]',
    ctaBg: 'bg-[#1E40AF]',
    ctaHover: 'hover:bg-[#1E3A8A]',
    cardBorder: 'border-[#93C5FD]',
    cardHoverBorder: 'hover:border-[#2563EB]',
    cardShadow: 'hover:shadow-[0_24px_48px_-14px_rgba(30,64,175,0.28)]',
    cardTitleHover: 'group-hover:text-[#1D4ED8]',
    laureateBg: 'bg-[#0F1E4A]',
    laureateBorder: 'border-[#1E3A8A]',
    laureateAccentText: 'text-[#93C5FD]',
    thingBoxLight: 'bg-[#EFF6FF] border-[#BFDBFE] text-[#1E3A8A]',
    thingBoxDark: 'bg-[#172B66] border-[#2563EB]/40 text-blue-100',
    thingLabelLight: 'text-[#1D4ED8]',
    thingLabelDark: 'text-[#93C5FD]',
    tabActiveBg: 'bg-[#1E40AF] text-white',
    swatchDot: 'bg-[#2563EB]',
  },
  sideman_of_the_year: {
    bandBg: 'bg-gradient-to-br from-[#D1FAE5] via-[#ECFDF5] to-[#CCFBF1]',
    bandBorder: 'border-[#6EE7B7]',
    headingText: 'text-[#022C22]',
    eyebrowText: 'text-[#047857]',
    mutedText: 'text-[#064E3B]',
    ctaBg: 'bg-[#065F46]',
    ctaHover: 'hover:bg-[#064E3B]',
    cardBorder: 'border-[#6EE7B7]',
    cardHoverBorder: 'hover:border-[#059669]',
    cardShadow: 'hover:shadow-[0_24px_48px_-14px_rgba(6,95,70,0.28)]',
    cardTitleHover: 'group-hover:text-[#047857]',
    laureateBg: 'bg-[#022C22]',
    laureateBorder: 'border-[#065F46]',
    laureateAccentText: 'text-[#6EE7B7]',
    thingBoxLight: 'bg-[#ECFDF5] border-[#A7F3D0] text-[#064E3B]',
    thingBoxDark: 'bg-[#053D30] border-[#10B981]/40 text-emerald-100',
    thingLabelLight: 'text-[#047857]',
    thingLabelDark: 'text-[#6EE7B7]',
    tabActiveBg: 'bg-[#065F46] text-white',
    swatchDot: 'bg-[#059669]',
  },
  moment_of_the_year: {
    bandBg: 'bg-gradient-to-br from-[#FFE4E6] via-[#FFF1F2] to-[#FCE7F3]',
    bandBorder: 'border-[#FDA4AF]',
    headingText: 'text-[#4C0519]',
    eyebrowText: 'text-[#BE123C]',
    mutedText: 'text-[#881337]',
    ctaBg: 'bg-[#9F1239]',
    ctaHover: 'hover:bg-[#881337]',
    cardBorder: 'border-[#FDA4AF]',
    cardHoverBorder: 'hover:border-[#E11D48]',
    cardShadow: 'hover:shadow-[0_24px_48px_-14px_rgba(159,18,57,0.28)]',
    cardTitleHover: 'group-hover:text-[#BE123C]',
    laureateBg: 'bg-[#4C0519]',
    laureateBorder: 'border-[#881337]',
    laureateAccentText: 'text-[#FDA4AF]',
    thingBoxLight: 'bg-[#FFF1F2] border-[#FECDD3] text-[#881337]',
    thingBoxDark: 'bg-[#6B0A26] border-[#F43F5E]/40 text-rose-100',
    thingLabelLight: 'text-[#BE123C]',
    thingLabelDark: 'text-[#FDA4AF]',
    tabActiveBg: 'bg-[#9F1239] text-white',
    swatchDot: 'bg-[#E11D48]',
  },
  funniest_person: {
    bandBg: 'bg-gradient-to-br from-[#EDE9FE] via-[#F3F0FF] to-[#FAE8FF]',
    bandBorder: 'border-[#C4B5FD]',
    headingText: 'text-[#2E1065]',
    eyebrowText: 'text-[#6D28D9]',
    mutedText: 'text-[#4C1D95]',
    ctaBg: 'bg-[#5B21B6]',
    ctaHover: 'hover:bg-[#4C1D95]',
    cardBorder: 'border-[#C4B5FD]',
    cardHoverBorder: 'hover:border-[#7C3AED]',
    cardShadow: 'hover:shadow-[0_24px_48px_-14px_rgba(91,33,182,0.28)]',
    cardTitleHover: 'group-hover:text-[#6D28D9]',
    laureateBg: 'bg-[#2E1065]',
    laureateBorder: 'border-[#5B21B6]',
    laureateAccentText: 'text-[#C4B5FD]',
    thingBoxLight: 'bg-[#F5F3FF] border-[#DDD6FE] text-[#4C1D95]',
    thingBoxDark: 'bg-[#43188F] border-[#8B5CF6]/40 text-violet-100',
    thingLabelLight: 'text-[#6D28D9]',
    thingLabelDark: 'text-[#C4B5FD]',
    tabActiveBg: 'bg-[#5B21B6] text-white',
    swatchDot: 'bg-[#7C3AED]',
  },
  little_boy_award: {
    bandBg: 'bg-gradient-to-br from-[#FFEDD5] via-[#FFF7ED] to-[#FEF3C7]',
    bandBorder: 'border-[#FDBA74]',
    headingText: 'text-[#431407]',
    eyebrowText: 'text-[#C2410C]',
    mutedText: 'text-[#7C2D12]',
    ctaBg: 'bg-[#C2410C]',
    ctaHover: 'hover:bg-[#9A3412]',
    cardBorder: 'border-[#FDBA74]',
    cardHoverBorder: 'hover:border-[#EA580C]',
    cardShadow: 'hover:shadow-[0_24px_48px_-14px_rgba(194,65,12,0.28)]',
    cardTitleHover: 'group-hover:text-[#C2410C]',
    laureateBg: 'bg-[#431407]',
    laureateBorder: 'border-[#9A3412]',
    laureateAccentText: 'text-[#FDBA74]',
    thingBoxLight: 'bg-[#FFF7ED] border-[#FED7AA] text-[#9A3412]',
    thingBoxDark: 'bg-[#6B210B] border-[#F97316]/40 text-orange-100',
    thingLabelLight: 'text-[#C2410C]',
    thingLabelDark: 'text-[#FDBA74]',
    tabActiveBg: 'bg-[#C2410C] text-white',
    swatchDot: 'bg-[#EA580C]',
  },
  best_debate: {
    bandBg: 'bg-gradient-to-br from-[#CFFAFE] via-[#ECFEFF] to-[#E0F2FE]',
    bandBorder: 'border-[#67E8F9]',
    headingText: 'text-[#083344]',
    eyebrowText: 'text-[#0E7490]',
    mutedText: 'text-[#155E75]',
    ctaBg: 'bg-[#0E7490]',
    ctaHover: 'hover:bg-[#155E75]',
    cardBorder: 'border-[#67E8F9]',
    cardHoverBorder: 'hover:border-[#0891B2]',
    cardShadow: 'hover:shadow-[0_24px_48px_-14px_rgba(14,116,144,0.28)]',
    cardTitleHover: 'group-hover:text-[#0E7490]',
    laureateBg: 'bg-[#083344]',
    laureateBorder: 'border-[#155E75]',
    laureateAccentText: 'text-[#67E8F9]',
    thingBoxLight: 'bg-[#ECFEFF] border-[#A5F3FC] text-[#155E75]',
    thingBoxDark: 'bg-[#0E4A61] border-[#06B6D4]/40 text-cyan-100',
    thingLabelLight: 'text-[#0E7490]',
    thingLabelDark: 'text-[#67E8F9]',
    tabActiveBg: 'bg-[#0E7490] text-white',
    swatchDot: 'bg-[#0891B2]',
  },
  honorable_mentions: {
    bandBg: 'bg-gradient-to-br from-[#FEF3C7] via-[#FFFBEB] to-[#FFEDD5]',
    bandBorder: 'border-[#FCD34D]',
    headingText: 'text-[#451A03]',
    eyebrowText: 'text-[#B45309]',
    mutedText: 'text-[#78350F]',
    ctaBg: 'bg-[#92400E]',
    ctaHover: 'hover:bg-[#78350F]',
    cardBorder: 'border-[#FCD34D]',
    cardHoverBorder: 'hover:border-[#D97706]',
    cardShadow: 'hover:shadow-[0_24px_48px_-14px_rgba(146,64,14,0.28)]',
    cardTitleHover: 'group-hover:text-[#B45309]',
    laureateBg: 'bg-[#451A03]',
    laureateBorder: 'border-[#78350F]',
    laureateAccentText: 'text-[#FCD34D]',
    thingBoxLight: 'bg-[#FFFBEB] border-[#FDE68A] text-[#78350F]',
    thingBoxDark: 'bg-[#5E2506] border-[#F59E0B]/40 text-amber-100',
    thingLabelLight: 'text-[#B45309]',
    thingLabelDark: 'text-[#FCD34D]',
    tabActiveBg: 'bg-[#92400E] text-white',
    swatchDot: 'bg-[#D97706]',
  },
};

export const CATEGORY_SLUGS: Record<AwardCategory, string> = {
  quote_of_the_year: 'quote-of-the-year',
  sideman_of_the_year: 'sideman-of-the-year',
  moment_of_the_year: 'moment-of-the-year',
  funniest_person: 'funniest-person',
  little_boy_award: 'little-boy-award',
  best_debate: 'best-debate',
  honorable_mentions: 'honorable-mentions',
};

export function getCategoryPath(category: AwardCategory): string {
  return `/categories/${CATEGORY_SLUGS[category]}`;
}

export function getCategoryFromPath(pathname: string): AwardCategory | null {
  const normalized = pathname.replace(/\/+$/, '').toLowerCase();
  const entry = (Object.entries(CATEGORY_SLUGS) as [AwardCategory, string][]).find(
    ([, slug]) => `/categories/${slug}` === normalized
  );
  return entry ? entry[0] : null;
}
