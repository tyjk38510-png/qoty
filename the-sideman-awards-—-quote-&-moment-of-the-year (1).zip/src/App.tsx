import { MouseEvent, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import {
  ArrowLeft,
  ArrowRight,
  Award,
  CheckCircle2,
  ChevronDown,
  Lock,
  Menu,
  RotateCcw,
  Search,
  ShieldCheck,
  Sparkles,
  Trophy,
  X,
} from 'lucide-react';
import { AdminDashboard } from './components/AdminDashboard';
import { AwardCard } from './components/AwardCard';
import { AwardImage } from './components/AwardImage';
import { CategoryRecapReveal } from './components/CategoryRecapReveal';
import { EntryDetailModal } from './components/EntryDetailModal';
import { QuirkyCategoryArt } from './components/QuirkyCategoryArt';
import { SocialFooter } from './components/SocialFooter';
import { HERO_STAGE_IMAGE } from './lib/defaultAssets';
import {
  AWARD_CATEGORIES,
  AwardCategory,
  AwardEntry,
  CATEGORY_THEMES,
  getCategoryFromPath,
  getCategoryPath,
} from './types';

type AppRoute =
  | { page: 'home' }
  | { page: 'winners' }
  | { page: 'category'; category: AwardCategory }
  | { page: 'admin' };

function parseRoute(pathname: string): AppRoute {
  const normalized = pathname.replace(/\/+$/, '').toLowerCase() || '/';
  if (normalized === '/admin') return { page: 'admin' };
  if (normalized === '/winners') return { page: 'winners' };
  const category = getCategoryFromPath(normalized);
  if (category) return { page: 'category', category };
  return { page: 'home' };
}

function getRouteKey(route: AppRoute): string {
  if (route.page === 'category') return `category-${route.category}`;
  return route.page;
}

export default function App() {
  const [entries, setEntries] = useState<AwardEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [route, setRoute] = useState<AppRoute>(() => parseRoute(window.location.pathname));
  const [completedCategories, setCompletedCategories] = useState<AwardCategory[]>(() => {
    try {
      const raw = localStorage.getItem('sideman_completed_categories');
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      const validIds = new Set(AWARD_CATEGORIES.map((c) => c.id));
      return parsed.filter((id): id is AwardCategory => validIds.has(id));
    } catch {
      return [];
    }
  });
  const [categoryPhase, setCategoryPhase] = useState<'recap' | 'all'>('recap');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEntry, setSelectedEntry] = useState<AwardEntry | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoriesMenuOpen, setCategoriesMenuOpen] = useState(false);
  const categoriesMenuRef = useRef<HTMLDivElement | null>(null);

  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminUsername, setAdminUsername] = useState<string | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem('sideman_admin_token');
    } catch {
      return null;
    }
  });

  useEffect(() => {
    let active = true;

    async function loadInitialData() {
      setIsLoading(true);
      try {
        const [entriesRes, sessionRes] = await Promise.all([
          fetch('/api/entries'),
          fetch('/api/auth/session', {
            headers: authToken ? { Authorization: `Bearer ${authToken}` } : undefined,
          }),
        ]);
        if (!entriesRes.ok) throw new Error('Unable to load award entries');
        const entriesJson = await entriesRes.json();
        const sessionJson = sessionRes.ok ? await sessionRes.json() : { authenticated: false };

        if (!active) return;
        const loadedEntries: AwardEntry[] = Array.isArray(entriesJson.entries)
          ? entriesJson.entries
          : [];
        setEntries(loadedEntries);
        setIsAuthenticated(Boolean(sessionJson.authenticated));
        setAdminUsername(sessionJson.username || null);

        const params = new URLSearchParams(window.location.search);
        const deepLinkId = params.get('entry');
        if (deepLinkId) {
          const matched = loadedEntries.find((item) => item.id === deepLinkId);
          if (matched) {
            setSelectedEntry(matched);
          }
        }
      } catch {
        if (!active) return;
        setLoadError('Unable to load awards archive right now.');
      } finally {
        if (active) setIsLoading(false);
      }
    }

    loadInitialData();
    return () => {
      active = false;
    };
  }, [authToken]);

  useEffect(() => {
    const handlePopState = () => {
      const nextRoute = parseRoute(window.location.pathname);
      setRoute(nextRoute);
      setMobileMenuOpen(false);
      setCategoriesMenuOpen(false);
      setSearchQuery('');

      const params = new URLSearchParams(window.location.search);
      const deepLinkId = params.get('entry');
      setCategoryPhase('recap');
      if (!deepLinkId) {
        setSelectedEntry(null);
        return;
      }
      const matched = entries.find((item) => item.id === deepLinkId) || null;
      setSelectedEntry(matched);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [entries]);

  useEffect(() => {
    if (!categoriesMenuOpen) return;
    const handleClickOutside = (event: globalThis.MouseEvent) => {
      if (
        categoriesMenuRef.current &&
        !categoriesMenuRef.current.contains(event.target as Node)
      ) {
        setCategoriesMenuOpen(false);
      }
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setCategoriesMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [categoriesMenuOpen]);

  function navigateTo(path: string, event?: MouseEvent) {
    if (event) {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0) {
        return;
      }
      event.preventDefault();
    }
    const targetUrl = new URL(path, window.location.origin);
    window.history.pushState(null, '', targetUrl.pathname);
    setRoute(parseRoute(targetUrl.pathname));
    setCategoryPhase('recap');
    setSelectedEntry(null);
    setMobileMenuOpen(false);
    setCategoriesMenuOpen(false);
    setSearchQuery('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleSelectEntry(entry: AwardEntry | null) {
    setSelectedEntry(entry);
    const url = new URL(window.location.href);
    if (entry) {
      url.searchParams.set('entry', entry.id);
    } else {
      url.searchParams.delete('entry');
    }
    window.history.replaceState(null, '', url.toString());
  }

  function handleLoginSuccess(username: string, token: string) {
    setIsAuthenticated(true);
    setAdminUsername(username);
    setAuthToken(token);
    try {
      localStorage.setItem('sideman_admin_token', token);
    } catch {
      // Ignore storage failures in restricted contexts
    }
  }

  async function handleLogout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // Proceed with local cleanup
    }
    try {
      localStorage.removeItem('sideman_admin_token');
    } catch {
      // Ignore storage failures
    }
    setIsAuthenticated(false);
    setAdminUsername(null);
    setAuthToken(null);
  }

  function markCategoryCompleted(category: AwardCategory) {
    setCompletedCategories((prev) => {
      if (prev.includes(category)) return prev;
      const next = [...prev, category];
      try {
        localStorage.setItem('sideman_completed_categories', JSON.stringify(next));
      } catch {
        // Ignore storage failures
      }
      return next;
    });
  }

  function resetPresentationProgress() {
    setCompletedCategories([]);
    setSearchQuery('');
    setCategoryPhase('recap');
    try {
      localStorage.removeItem('sideman_completed_categories');
    } catch {
      // Ignore storage failures
    }
  }

  const allCategoriesCompleted = useMemo(
    () => AWARD_CATEGORIES.every((cat) => completedCategories.includes(cat.id)),
    [completedCategories]
  );

  const nextUncompletedCategory = useMemo(
    () =>
      AWARD_CATEGORIES.find((cat) => !completedCategories.includes(cat.id)) ||
      AWARD_CATEGORIES[0],
    [completedCategories]
  );

  const canUseGlobalSearch =
    allCategoriesCompleted && (route.page !== 'category' || categoryPhase === 'all');

  const normalizedSearch = canUseGlobalSearch ? searchQuery.trim().toLowerCase() : '';

  const matchingEntries = useMemo(() => {
    if (!normalizedSearch) return entries;
    return entries.filter(
      (item) =>
        item.nomineeName.toLowerCase().includes(normalizedSearch) ||
        (item.signatureThing || '').toLowerCase().includes(normalizedSearch) ||
        item.quote.toLowerCase().includes(normalizedSearch) ||
        item.title.toLowerCase().includes(normalizedSearch) ||
        item.episode.toLowerCase().includes(normalizedSearch)
    );
  }, [entries, normalizedSearch]);

  const winners = useMemo(
    () => matchingEntries.filter((e) => e.tier === 'winner'),
    [matchingEntries]
  );

  const activeCategoryMeta =
    route.page === 'category'
      ? AWARD_CATEGORIES.find((c) => c.id === route.category) || null
      : null;
  const activeCategoryTheme =
    route.page === 'category' ? CATEGORY_THEMES[route.category] : null;
  const activeCategoryIndex = activeCategoryMeta
    ? AWARD_CATEGORIES.findIndex((c) => c.id === activeCategoryMeta.id)
    : -1;
  const prevCategory =
    activeCategoryIndex > 0
      ? AWARD_CATEGORIES[activeCategoryIndex - 1]
      : AWARD_CATEGORIES[AWARD_CATEGORIES.length - 1];
  const nextCategory =
    activeCategoryIndex >= 0 && activeCategoryIndex < AWARD_CATEGORIES.length - 1
      ? AWARD_CATEGORIES[activeCategoryIndex + 1]
      : AWARD_CATEGORIES[0];

  return (
    <MotionConfig reducedMotion="user">
      <div className="relative min-h-screen overflow-x-hidden bg-gradient-to-br from-[#FFF4E6] via-[#F7F2FF] to-[#E6FAFF] text-[#1C1917]">
        {/* Ambient Colorful Surroundings Glow */}
        <div
          aria-hidden="true"
          className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
        >
          <div className="absolute -left-24 -top-24 h-96 w-96 rounded-full bg-amber-300/30 blur-3xl" />
          <div className="absolute right-0 top-1/4 h-[28rem] w-[28rem] rounded-full bg-violet-300/25 blur-3xl" />
          <div className="absolute bottom-0 left-1/3 h-96 w-96 rounded-full bg-cyan-300/25 blur-3xl" />
          <div className="absolute -bottom-24 right-1/4 h-80 w-80 rounded-full bg-rose-300/25 blur-3xl" />
        </div>

        {/* Strict 3-Zone Top Bar Contract with Celebratory Color Trim */}
        <header className="sticky top-0 z-40 border-b border-indigo-200/70 bg-white/85 backdrop-blur-md">
          <div className="h-1 w-full bg-gradient-to-r from-[#2563EB] via-[#E11D48] via-[#D97706] via-[#7C3AED] to-[#0891B2]" />
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-6 py-4">
            {/* Zone 1: Brand Wordmark */}
            <a
              href="/"
              onClick={(e) => navigateTo('/', e)}
              className="font-serif text-xl font-bold tracking-tight text-stone-900 whitespace-nowrap shrink-0"
            >
              The Sideman Awards
            </a>

            {/* Zone 2: Single-line Page Links (max 5 items) */}
            <nav
              aria-label="Awards Pages"
              className="hidden items-center gap-6 text-sm font-medium text-stone-600 lg:flex"
            >
              <a
                href="/"
                onClick={(e) => navigateTo('/', e)}
                className={`relative py-1 transition-colors hover:text-stone-900 whitespace-nowrap shrink-0 ${
                  route.page === 'home'
                    ? 'font-semibold text-stone-900 underline decoration-amber-600 decoration-2 underline-offset-8'
                    : ''
                }`}
              >
                Home
              </a>
              <a
                href="/winners"
                onClick={(e) => navigateTo('/winners', e)}
                className={`relative py-1 transition-colors hover:text-stone-900 whitespace-nowrap shrink-0 ${
                  route.page === 'winners'
                    ? 'font-semibold text-amber-800 underline decoration-amber-600 decoration-2 underline-offset-8'
                    : ''
                }`}
              >
                Winners
              </a>
              <a
                href={getCategoryPath('quote_of_the_year')}
                onClick={(e) => navigateTo(getCategoryPath('quote_of_the_year'), e)}
                className={`relative py-1 transition-colors hover:text-stone-900 whitespace-nowrap shrink-0 ${
                  route.page === 'category' && route.category === 'quote_of_the_year'
                    ? `font-semibold ${CATEGORY_THEMES.quote_of_the_year.eyebrowText} underline decoration-2 underline-offset-8`
                    : ''
                }`}
              >
                Quote of the Year
              </a>
              <a
                href={getCategoryPath('sideman_of_the_year')}
                onClick={(e) => navigateTo(getCategoryPath('sideman_of_the_year'), e)}
                className={`relative py-1 transition-colors hover:text-stone-900 whitespace-nowrap shrink-0 ${
                  route.page === 'category' && route.category === 'sideman_of_the_year'
                    ? `font-semibold ${CATEGORY_THEMES.sideman_of_the_year.eyebrowText} underline decoration-2 underline-offset-8`
                    : ''
                }`}
              >
                Sideman of the Year
              </a>

              <div className="relative shrink-0" ref={categoriesMenuRef}>
                <button
                  type="button"
                  onClick={() => setCategoriesMenuOpen((prev) => !prev)}
                  aria-expanded={categoriesMenuOpen}
                  aria-haspopup="menu"
                  className={`inline-flex items-center gap-1.5 py-1 transition-colors hover:text-stone-900 whitespace-nowrap shrink-0 ${
                    route.page === 'category' &&
                    route.category !== 'quote_of_the_year' &&
                    route.category !== 'sideman_of_the_year'
                      ? `font-semibold ${activeCategoryTheme?.eyebrowText || 'text-stone-900'} underline decoration-2 underline-offset-8`
                      : ''
                  }`}
                >
                  All Categories
                  <ChevronDown
                    className={`h-3.5 w-3.5 transition-transform duration-150 ${
                      categoriesMenuOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {categoriesMenuOpen && (
                  <div
                    role="menu"
                    className="absolute right-0 top-full z-50 mt-3 w-72 rounded-2xl border border-stone-200 bg-white p-2 shadow-xl"
                  >
                    <div className="px-3 py-1.5 text-[11px] font-semibold text-stone-500">
                      7 Category Pages
                    </div>
                    <div className="mt-1 flex flex-col gap-1">
                      {AWARD_CATEGORIES.map((cat) => {
                        const isCurrent =
                          route.page === 'category' && route.category === cat.id;
                        const catTheme = CATEGORY_THEMES[cat.id];
                        const path = getCategoryPath(cat.id);
                        const isCatDone = completedCategories.includes(cat.id);
                        return (
                          <a
                            key={cat.id}
                            role="menuitem"
                            href={path}
                            onClick={(e) => navigateTo(path, e)}
                            className={`flex items-center justify-between rounded-xl px-3 py-2 text-xs transition-colors ${
                              isCurrent
                                ? `${catTheme.bandBg} ${catTheme.headingText} font-semibold`
                                : 'text-stone-700 hover:bg-stone-50 hover:text-stone-900'
                            }`}
                          >
                            <span className="flex min-w-0 items-center gap-2">
                              <span className={`h-2 w-2 shrink-0 rounded-full ${catTheme.swatchDot}`} />
                              <span className="truncate">{cat.label}</span>
                            </span>
                            {isCatDone && (
                              <CheckCircle2 className="ml-3 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                            )}
                          </a>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </nav>

            {/* Zone 3: Single Primary Action */}
            <div className="flex items-center gap-3 shrink-0">
              <a
                href={route.page === 'admin' ? '/' : '/admin'}
                onClick={(e) => navigateTo(route.page === 'admin' ? '/' : '/admin', e)}
                className="inline-flex items-center gap-2 rounded-lg bg-stone-900 px-4 py-2 text-xs font-medium text-white transition-colors duration-150 hover:bg-stone-800 whitespace-nowrap shrink-0"
              >
                <ShieldCheck className="h-3.5 w-3.5 text-amber-400" />
                {route.page === 'admin'
                  ? 'Public Showcase'
                  : isAuthenticated
                    ? 'Admin Studio'
                    : 'Admin Login'}
              </a>

              <button
                type="button"
                onClick={() => setMobileMenuOpen((prev) => !prev)}
                aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-stone-200 text-stone-700 lg:hidden"
              >
                {mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {/* Mobile Drawer */}
          {mobileMenuOpen && (
            <nav className="border-t border-stone-200 bg-[#FBF9F5] px-6 py-4 lg:hidden">
              <div className="flex flex-col gap-3 text-sm font-medium text-stone-700">
                <a
                  href="/"
                  onClick={(e) => navigateTo('/', e)}
                  className="py-1 hover:text-stone-900"
                >
                  Home Overview
                </a>
                <a
                  href="/winners"
                  onClick={(e) => navigateTo('/winners', e)}
                  className="py-1 hover:text-stone-900"
                >
                  Winners
                </a>
                {AWARD_CATEGORIES.map((cat) => (
                  <a
                    key={cat.id}
                    href={getCategoryPath(cat.id)}
                    onClick={(e) => navigateTo(getCategoryPath(cat.id), e)}
                    className="py-1 hover:text-stone-900"
                  >
                    {cat.label}
                  </a>
                ))}
              </div>
            </nav>
          )}
        </header>

        <AnimatePresence mode="wait">
          {route.page === 'admin' ? (
            <motion.div
              key="page-admin"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
            >
              <AdminDashboard
                entries={entries}
                isAuthenticated={isAuthenticated}
                adminUsername={adminUsername}
                authToken={authToken}
                onLoginSuccess={handleLoginSuccess}
                onLogout={handleLogout}
                onEntriesChange={setEntries}
                onBackToSite={() => navigateTo('/')}
              />
            </motion.div>
          ) : route.page === 'category' && activeCategoryMeta && activeCategoryTheme ? (
            /* DEDICATED STANDALONE CATEGORY PAGE */
            <motion.main
              key={getRouteKey(route)}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="mx-auto max-w-7xl px-6 pb-20 pt-8"
            >
              <div
                className={`relative overflow-hidden rounded-3xl border p-6 sm:p-10 ${activeCategoryTheme.bandBg} ${activeCategoryTheme.bandBorder}`}
              >
                {/* Quirky Category Art Background (rendered behind the all-at-once showcase) */}
                {(categoryPhase === 'all' || Boolean(normalizedSearch)) && (
                  <QuirkyCategoryArt category={activeCategoryMeta.id} />
                )}

                {/* Page Top Breadcrumb & Category Switcher */}
                <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <a
                      href="/"
                      onClick={(e) => navigateTo('/', e)}
                      className="inline-flex items-center gap-2 rounded-lg border border-stone-300/80 bg-white/95 px-3.5 py-2 text-xs font-medium text-stone-800 transition-colors hover:bg-white"
                    >
                      <ArrowLeft className="h-3.5 w-3.5" />
                      Back to Home
                    </a>
                    {(categoryPhase === 'all' || Boolean(normalizedSearch)) && (
                      <button
                        type="button"
                        onClick={() => {
                          setSearchQuery('');
                          setCategoryPhase('recap');
                        }}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300/80 bg-white/95 px-3.5 py-2 text-xs font-medium text-stone-800 transition-colors hover:bg-white"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        Replay Recap
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <a
                      href={getCategoryPath(prevCategory.id)}
                      onClick={(e) => navigateTo(getCategoryPath(prevCategory.id), e)}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300/80 bg-white/95 px-3 py-2 text-xs font-medium text-stone-800 transition-colors hover:bg-white whitespace-nowrap"
                    >
                      <ArrowLeft className="h-3.5 w-3.5" />
                      {prevCategory.shortLabel}
                    </a>
                    <a
                      href={getCategoryPath(nextCategory.id)}
                      onClick={(e) => navigateTo(getCategoryPath(nextCategory.id), e)}
                      className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-medium text-white transition-colors whitespace-nowrap ${activeCategoryTheme.ctaBg} ${activeCategoryTheme.ctaHover}`}
                    >
                      Next: {nextCategory.shortLabel}
                      <ArrowRight className="h-3.5 w-3.5" />
                    </a>
                  </div>
                </div>

                {/* Category Page Header + Post-Presentation Search */}
                <div className="relative z-10 mt-8 flex flex-col gap-6 border-b border-black/10 pb-8 lg:flex-row lg:items-end lg:justify-between">
                  <div>
                    <div
                      className={`flex items-center gap-2 text-xs font-semibold ${activeCategoryTheme.eyebrowText}`}
                    >
                      <span className="font-mono tabular-nums">
                        Category 0{activeCategoryIndex + 1}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {categoryPhase === 'recap' && !normalizedSearch
                          ? 'Presentation · 30s Per Nominee'
                          : activeCategoryMeta.hasWinner
                            ? 'All Nominees & Winner'
                            : 'All Honorable Mentions'}
                      </span>
                    </div>
                    <h1
                      className={`mt-2 font-serif text-4xl font-semibold tracking-tight sm:text-5xl lg:text-6xl ${activeCategoryTheme.headingText}`}
                    >
                      {activeCategoryMeta.label}
                    </h1>
                    <p
                      className={`mt-3 max-w-2xl text-base leading-relaxed ${activeCategoryTheme.mutedText}`}
                    >
                      {activeCategoryMeta.description}
                    </p>
                  </div>

                  {categoryPhase === 'all' && allCategoriesCompleted ? (
                    <div className="relative w-full lg:w-72">
                      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
                      <input
                        type="search"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder={`Search in ${activeCategoryMeta.shortLabel}...`}
                        aria-label={`Search in ${activeCategoryMeta.label}`}
                        className="w-full rounded-lg border border-stone-300 bg-white py-2.5 pl-9 pr-3 text-sm text-stone-900 placeholder:text-stone-400 focus:border-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-700/15"
                      />
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-2 rounded-lg border border-black/10 bg-white/85 px-3.5 py-2 text-xs font-medium text-stone-700">
                      <Lock className="h-3.5 w-3.5 text-stone-500" />
                      <span>
                        Search unlocks after all {AWARD_CATEGORIES.length} categories ({completedCategories.length}/{AWARD_CATEGORIES.length})
                      </span>
                    </div>
                  )}
                </div>

                {isLoading ? (
                  <div className="relative z-10 mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {[1, 2, 3].map((idx) => (
                      <div
                        key={idx}
                        className="h-96 animate-pulse rounded-xl border border-stone-200 bg-white/70"
                      />
                    ))}
                  </div>
                ) : loadError ? (
                  <div className="relative z-10 mt-8 rounded-2xl border border-red-200 bg-white p-10 text-center">
                    <p className="text-sm text-red-700">{loadError}</p>
                  </div>
                ) : (
                  (() => {
                    const categoryEntries = matchingEntries
                      .filter((e) => e.category === activeCategoryMeta.id)
                      .sort((a, b) => {
                        if (a.tier === 'winner' && b.tier !== 'winner') return -1;
                        if (b.tier === 'winner' && a.tier !== 'winner') return 1;
                        return 0;
                      });

                    if (categoryEntries.length === 0) {
                      return (
                        <div className="relative z-10 mt-8 rounded-2xl border border-stone-200 bg-white p-12 text-center">
                          <p className="text-sm text-stone-600">
                            No entries found in {activeCategoryMeta.label}. Use the Admin Portal to add nominees.
                          </p>
                        </div>
                      );
                    }

                    const showRecap = categoryPhase === 'recap' && !normalizedSearch;

                    return (
                      <AnimatePresence mode="wait">
                        {showRecap ? (
                          <motion.div
                            key={`recap-stage-${activeCategoryMeta.id}`}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0, scale: 0.96, filter: 'blur(6px)' }}
                            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                            className="relative z-10"
                          >
                            <CategoryRecapReveal
                              category={activeCategoryMeta.id}
                              categoryLabel={activeCategoryMeta.label}
                              entries={categoryEntries}
                              hasCompletedBefore={completedCategories.includes(
                                activeCategoryMeta.id
                              )}
                              onComplete={() => {
                                markCategoryCompleted(activeCategoryMeta.id);
                                setCategoryPhase('all');
                              }}
                              onSelectEntry={handleSelectEntry}
                            />
                          </motion.div>
                        ) : (
                          <motion.div
                            key={`all-stage-${activeCategoryMeta.id}`}
                            initial={{ opacity: 0, y: 24, scale: 0.98 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: -12 }}
                            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                            className="relative z-10"
                          >
                            {/* Nominee Roster Reveal Strip: Portrait + Name + Their Thing */}
                            <div className="mt-8">
                              <div
                                className={`mb-4 flex items-center gap-2 text-xs font-semibold ${activeCategoryTheme.eyebrowText}`}
                              >
                                <Sparkles className="h-3.5 w-3.5" />
                                <span>
                                  Complete Lineup ({categoryEntries.length}) — Portrait &amp; Signature Thing
                                </span>
                              </div>
                              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                                {categoryEntries.map((item, idx) => (
                                  <motion.button
                                    key={`roster-${item.id}`}
                                    type="button"
                                    initial={{ opacity: 0, y: 12 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{
                                      duration: 0.28,
                                      delay: Math.min(idx * 0.05, 0.3),
                                      ease: [0.16, 1, 0.3, 1],
                                    }}
                                    onClick={() => handleSelectEntry(item)}
                                    className={`group flex items-center gap-3.5 rounded-xl border bg-white/95 p-3 text-left backdrop-blur-sm transition-all duration-200 hover:-translate-y-0.5 ${activeCategoryTheme.cardBorder} ${activeCategoryTheme.cardHoverBorder}`}
                                  >
                                    <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg border border-stone-200">
                                      <AwardImage
                                        src={item.imageUrl}
                                        alt={item.nomineeName}
                                        fallbackLabel={item.nomineeName}
                                        aspectClassName="h-full w-full"
                                      />
                                    </div>
                                    <div className="min-w-0 flex-1">
                                      <div className="flex items-center gap-1.5 text-[11px] font-semibold">
                                        {item.tier === 'winner' && (
                                          <Trophy className="h-3 w-3 shrink-0 text-amber-600" />
                                        )}
                                        <span className={activeCategoryTheme.eyebrowText}>
                                          {item.tier === 'winner'
                                            ? 'Winner'
                                            : item.tier === 'honorable_mention'
                                              ? 'Honorable Mention'
                                              : 'Nominee'}
                                        </span>
                                      </div>
                                      <p className="truncate text-sm font-semibold text-stone-900">
                                        {item.nomineeName}
                                      </p>
                                      <p className="mt-0.5 line-clamp-2 text-xs text-stone-600">
                                        {item.signatureThing || item.title}
                                      </p>
                                    </div>
                                  </motion.button>
                                ))}
                              </div>
                            </div>

                            {/* Full Staggered Nominee & Winner Reveal Grid */}
                            <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                              {categoryEntries.map((entry, idx) => (
                                <AwardCard
                                  key={entry.id}
                                  entry={entry}
                                  onSelect={handleSelectEntry}
                                  revealMode
                                  index={idx}
                                />
                              ))}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    );
                  })()
                )}
              </div>
            </motion.main>
          ) : route.page === 'winners' ? (
            /* DEDICATED WINNERS PAGE */
            <motion.main
              key="page-winners"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
              className="mx-auto max-w-7xl px-6 pb-20 pt-8"
            >
              <section className="rounded-3xl border border-stone-800 bg-[#141210] p-6 text-stone-100 sm:p-10">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <a
                    href="/"
                    onClick={(e) => navigateTo('/', e)}
                    className="inline-flex items-center gap-2 rounded-lg border border-stone-700 bg-stone-900 px-3.5 py-2 text-xs font-medium text-stone-200 transition-colors hover:bg-stone-800"
                  >
                    <ArrowLeft className="h-3.5 w-3.5" />
                    Back to Home
                  </a>

                  {allCategoriesCompleted ? (
                    <div className="relative w-full sm:w-72">
                      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
                      <input
                        type="search"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search winners..."
                        aria-label="Search winners"
                        className="w-full rounded-lg border border-stone-700 bg-stone-900 py-2 pl-9 pr-3 text-sm text-stone-100 placeholder:text-stone-400 focus:border-amber-500 focus:outline-none"
                      />
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-2 rounded-lg border border-stone-700 bg-stone-900/90 px-3.5 py-2 text-xs text-stone-300">
                      <Lock className="h-3.5 w-3.5 text-amber-400" />
                      <span>
                        Complete all {AWARD_CATEGORIES.length} category presentations to unlock search
                      </span>
                    </div>
                  )}
                </div>

                <div className="mt-8 border-b border-stone-800 pb-6">
                  <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
                    <Trophy className="h-4 w-4" />
                    <span>2026 Grand Laureates</span>
                  </div>
                  <h1 className="mt-2 font-serif text-4xl font-semibold text-white sm:text-5xl">
                    Category Winners
                  </h1>
                  <p className="mt-3 max-w-2xl text-base text-stone-300">
                    The crowned champions across Quote of the Year, Sideman of the Year, Moment of the Year, Funniest Person, Little Boy Award, and Best Debate.
                  </p>
                </div>

                {isLoading ? (
                  <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {[1, 2, 3].map((idx) => (
                      <div
                        key={idx}
                        className="h-96 animate-pulse rounded-xl border border-stone-800 bg-stone-900"
                      />
                    ))}
                  </div>
                ) : winners.length === 0 ? (
                  <div className="mt-8 rounded-2xl border border-stone-800 bg-stone-900/60 p-10 text-center">
                    <Award className="mx-auto h-7 w-7 text-stone-500" />
                    <p className="mt-3 text-sm text-stone-400">
                      No winners match your current search.
                    </p>
                  </div>
                ) : (
                  <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {winners.map((winner, idx) => (
                      <AwardCard
                        key={winner.id}
                        entry={winner}
                        onSelect={handleSelectEntry}
                        variant="laureate"
                        revealMode
                        index={idx}
                      />
                    ))}
                  </div>
                )}
              </section>
            </motion.main>
          ) : (
            /* HOME OVERVIEW PAGE */
            <motion.main
              key="page-home"
              id="top"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.26, ease: [0.16, 1, 0.3, 1] }}
            >
              {/* Editorial Hero Split */}
              <section className="mx-auto max-w-7xl px-6 pb-8 pt-10 lg:pt-14">
                <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12">
                  <div className="flex flex-col justify-between rounded-3xl border border-amber-200/80 bg-gradient-to-br from-white via-[#FFF9EC] to-[#EFF4FF] p-8 shadow-lg shadow-indigo-950/5 sm:p-10 lg:col-span-7">
                    <div>
                      <div className="flex items-center gap-2 text-xs font-semibold text-indigo-700">
                        <span>2026 Annual Edition</span>
                        <span aria-hidden="true">·</span>
                        <span className="text-rose-700">Sealed Ceremony Showcase</span>
                      </div>

                      <h1 className="mt-4 max-w-2xl text-balance font-serif text-4xl font-semibold leading-[1.08] tracking-tight text-stone-900 sm:text-5xl lg:text-6xl">
                        Sideman’s Quote &amp; Moment of the Year
                      </h1>

                      <p className="mt-5 max-w-xl text-base leading-relaxed text-stone-700">
                        Enter each individual category room to reveal the mystery lineup one spotlight at a time. Once every category presentation is complete, the full quotes archive and search unlock at the bottom of this page.
                      </p>
                    </div>

                    <div className="mt-8 flex flex-wrap items-center gap-3 border-t border-indigo-100 pt-6">
                      <a
                        href={getCategoryPath(nextUncompletedCategory.id)}
                        onClick={(e) =>
                          navigateTo(getCategoryPath(nextUncompletedCategory.id), e)
                        }
                        className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#1E40AF] via-[#6D28D9] to-[#BE123C] px-5 py-2.5 text-sm font-semibold text-white shadow-md shadow-indigo-900/20 transition-all duration-200 hover:-translate-y-0.5 hover:brightness-110"
                      >
                        {allCategoriesCompleted
                          ? 'Revisit Quote of the Year'
                          : completedCategories.length === 0
                            ? 'Start Category Presentation'
                            : `Continue: ${nextUncompletedCategory.shortLabel}`}
                        <ArrowRight className="h-4 w-4" />
                      </a>
                      {allCategoriesCompleted && (
                        <a
                          href="/winners"
                          onClick={(e) => navigateTo('/winners', e)}
                          className="inline-flex items-center gap-2 rounded-xl bg-stone-900 px-5 py-2.5 text-sm font-medium text-white transition-all duration-200 hover:-translate-y-0.5 hover:bg-stone-800"
                        >
                          <Trophy className="h-4 w-4 text-amber-400" />
                          Explore 2026 Winners
                        </a>
                      )}
                    </div>
                  </div>

                  <div className="group relative overflow-hidden rounded-3xl border border-violet-300/60 bg-indigo-950 shadow-lg shadow-indigo-950/15 lg:col-span-5">
                    <img
                      src={HERO_STAGE_IMAGE}
                      alt="Vintage brass broadcast microphone on a walnut podium in a warm theater"
                      referrerPolicy="no-referrer"
                      className="h-72 w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105 sm:h-96 lg:h-full"
                    />
                    <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#1E1B4B]/90 via-[#4C1D95]/30 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-6 text-stone-100">
                      <p className="text-xs font-semibold text-amber-300">Main Hall Showcase</p>
                      <p className="mt-1 font-serif text-xl font-medium">
                        Seven vibrant category rooms—sealed until you step inside.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Colorful 4-Column Mystery Strip (no winner/nominee indicators) */}
                <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
                  <div className="rounded-2xl border border-blue-200 bg-gradient-to-br from-[#DBEAFE] to-white p-5">
                    <p className="text-xs font-medium text-blue-800">Categories Explored</p>
                    <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-blue-950">
                      {completedCategories.length} / {AWARD_CATEGORIES.length}
                    </p>
                  </div>
                  <div className="rounded-2xl border border-violet-200 bg-gradient-to-br from-[#EDE9FE] to-white p-5">
                    <p className="text-xs font-medium text-violet-800">Award Rooms</p>
                    <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-violet-950">
                      {AWARD_CATEGORIES.length} Pages
                    </p>
                  </div>
                  <div className="rounded-2xl border border-amber-200 bg-gradient-to-br from-[#FEF3C7] to-white p-5">
                    <p className="text-xs font-medium text-amber-800">Spotlight Pacing</p>
                    <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-amber-950">
                      30s+ Reveal
                    </p>
                  </div>
                  <div className="rounded-2xl border border-emerald-200 bg-gradient-to-br from-[#D1FAE5] to-white p-5">
                    <p className="text-xs font-medium text-emerald-800">Archive Status</p>
                    <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-emerald-950">
                      {allCategoriesCompleted ? 'Unlocked' : 'Sealed'}
                    </p>
                  </div>
                </div>
              </section>

              {/* Category Pages Directory (Mystery Cards — zero winner/nominee indicators) */}
              <section className="mx-auto max-w-7xl px-6 py-8">
                <div className="flex flex-col gap-2 border-b border-indigo-200/70 pb-5 sm:flex-row sm:items-end sm:justify-between">
                  <div>
                    <p className="text-xs font-semibold text-violet-700">Award Categories</p>
                    <h2 className="mt-1 font-serif text-3xl font-semibold text-stone-900 sm:text-4xl">
                      Enter a Category Room
                    </h2>
                  </div>
                  <p className="max-w-md text-sm text-stone-700">
                    Every lineup stays hidden from the homepage to keep the reveal a surprise. Step into any category room to discover who is inside.
                  </p>
                </div>

                <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
                  {AWARD_CATEGORIES.map((cat, idx) => {
                    const catTheme = CATEGORY_THEMES[cat.id];
                    const catPath = getCategoryPath(cat.id);
                    const isCompleted = completedCategories.includes(cat.id);

                    return (
                      <a
                        key={cat.id}
                        href={catPath}
                        onClick={(e) => navigateTo(catPath, e)}
                        className={`group flex flex-col justify-between rounded-3xl border p-7 transition-all duration-300 ease-out hover:-translate-y-1.5 ${catTheme.bandBg} ${catTheme.bandBorder} ${catTheme.cardShadow}`}
                      >
                        <div>
                          <div
                            className={`flex items-center justify-between text-xs font-semibold ${catTheme.eyebrowText}`}
                          >
                            <span className="font-mono tabular-nums">
                              0{idx + 1}. Sealed Category
                            </span>
                            <span className="inline-flex items-center gap-1.5 font-mono tabular-nums">
                              {isCompleted ? (
                                <>
                                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-700" />
                                  Completed
                                </>
                              ) : (
                                <>
                                  <Lock className="h-3.5 w-3.5" />
                                  Mystery Lineup
                                </>
                              )}
                            </span>
                          </div>

                          <h3
                            className={`mt-3 font-serif text-3xl font-semibold tracking-tight ${catTheme.headingText}`}
                          >
                            {cat.label}
                          </h3>
                          <p className={`mt-2 text-sm leading-relaxed ${catTheme.mutedText}`}>
                            {cat.description}
                          </p>
                        </div>

                        <div className="mt-6 flex items-center justify-between border-t border-black/10 pt-4">
                          <span className={`text-xs font-semibold ${catTheme.eyebrowText}`}>
                            {isCompleted ? `Revisit ${cat.label}` : `Open ${cat.label} Presentation`}
                          </span>
                          <span
                            className={`inline-flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-semibold text-white transition-transform duration-200 group-hover:translate-x-0.5 ${catTheme.ctaBg}`}
                          >
                            {isCompleted ? 'View Category' : 'Reveal Inside'}
                            <ArrowRight className="h-3.5 w-3.5" />
                          </span>
                        </div>
                      </a>
                    );
                  })}
                </div>
              </section>

              {/* Bottom of Homepage: Locked until all individual category presentations are completed */}
              <section className="mx-auto max-w-7xl px-6 pb-20 pt-6">
                {!allCategoriesCompleted ? (
                  <div className="rounded-3xl border border-indigo-800/70 bg-gradient-to-br from-[#13111C] via-[#1E1B4B] to-[#0F172A] p-6 text-stone-100 shadow-xl sm:p-10">
                    <div className="flex flex-col gap-4 border-b border-white/15 pb-6 sm:flex-row sm:items-end sm:justify-between">
                      <div>
                        <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
                          <Lock className="h-3.5 w-3.5" />
                          <span>Full Archive &amp; Search Locked</span>
                        </div>
                        <h2 className="mt-1 font-serif text-3xl font-semibold text-white sm:text-4xl">
                          Explore Every Category First
                        </h2>
                        <p className="mt-2 max-w-2xl text-sm text-indigo-100/85">
                          To keep every nominee and winner a mystery, all quotes and quote search stay hidden until you complete each individual category presentation ({completedCategories.length} of {AWARD_CATEGORIES.length} completed).
                        </p>
                      </div>

                      <a
                        href={getCategoryPath(nextUncompletedCategory.id)}
                        onClick={(e) =>
                          navigateTo(getCategoryPath(nextUncompletedCategory.id), e)
                        }
                        className="inline-flex items-center gap-2 self-start rounded-xl bg-gradient-to-r from-amber-400 to-orange-400 px-4 py-2.5 text-xs font-semibold text-stone-950 shadow-md transition-all hover:brightness-105 sm:self-auto whitespace-nowrap shrink-0"
                      >
                        Next: {nextUncompletedCategory.label}
                        <ArrowRight className="h-3.5 w-3.5" />
                      </a>
                    </div>

                    {/* Progress bar */}
                    <div className="mt-6">
                      <div className="flex items-center justify-between text-xs text-indigo-200">
                        <span>Presentation Progress</span>
                        <span className="font-mono tabular-nums text-amber-300">
                          {completedCategories.length} / {AWARD_CATEGORIES.length} Categories
                        </span>
                      </div>
                      <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-white/10">
                        <div
                          style={{
                            transform: `scaleX(${completedCategories.length / AWARD_CATEGORIES.length})`,
                            transformOrigin: 'left center',
                          }}
                          className="h-full rounded-full bg-gradient-to-r from-amber-400 via-rose-400 to-cyan-400 transition-transform duration-300 ease-out"
                        />
                      </div>
                    </div>

                    <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                      {AWARD_CATEGORIES.map((cat) => {
                        const done = completedCategories.includes(cat.id);
                        const catTheme = CATEGORY_THEMES[cat.id];
                        return (
                          <a
                            key={`progress-${cat.id}`}
                            href={getCategoryPath(cat.id)}
                            onClick={(e) => navigateTo(getCategoryPath(cat.id), e)}
                            className={`flex items-center justify-between rounded-xl border px-4 py-3 text-xs font-medium transition-colors ${
                              done
                                ? 'border-emerald-500/50 bg-emerald-950/40 text-emerald-200'
                                : 'border-white/15 bg-white/5 text-indigo-100 hover:border-white/30 hover:bg-white/10'
                            }`}
                          >
                            <span className="flex min-w-0 items-center gap-2">
                              <span className={`h-2 w-2 shrink-0 rounded-full ${catTheme.swatchDot}`} />
                              <span className="truncate">{cat.label}</span>
                            </span>
                            {done ? (
                              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                            ) : (
                              <ArrowRight className="h-3.5 w-3.5 shrink-0 text-indigo-300" />
                            )}
                          </a>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-10">
                    {/* Unlocked Winners Showcase Band */}
                    <div className="rounded-3xl border border-stone-800 bg-[#141210] p-6 text-stone-100 sm:p-10">
                      <div className="flex flex-col gap-3 border-b border-stone-800 pb-5 sm:flex-row sm:items-end sm:justify-between">
                        <div>
                          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400">
                            <Trophy className="h-3.5 w-3.5" />
                            <span>2026 Laureates · Presentation Complete</span>
                          </div>
                          <h2 className="mt-1 font-serif text-3xl font-semibold text-white sm:text-4xl">
                            Category Winners
                          </h2>
                        </div>
                        <div className="flex flex-wrap items-center gap-3">
                          <button
                            type="button"
                            onClick={resetPresentationProgress}
                            className="inline-flex items-center gap-1.5 rounded-lg border border-stone-700 bg-stone-900 px-3.5 py-2 text-xs font-medium text-stone-300 transition-colors hover:bg-stone-800 hover:text-white"
                          >
                            <RotateCcw className="h-3.5 w-3.5" />
                            Replay Presentation Lock
                          </button>
                          <a
                            href="/winners"
                            onClick={(e) => navigateTo('/winners', e)}
                            className="inline-flex items-center gap-2 rounded-lg border border-stone-700 bg-stone-900 px-4 py-2 text-xs font-medium text-stone-100 transition-colors hover:bg-stone-800"
                          >
                            Open Winners Page
                            <ArrowRight className="h-3.5 w-3.5 text-amber-400" />
                          </a>
                        </div>
                      </div>

                      {isLoading ? (
                        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                          {[1, 2, 3].map((idx) => (
                            <div
                              key={idx}
                              className="h-96 animate-pulse rounded-xl border border-stone-800 bg-stone-900"
                            />
                          ))}
                        </div>
                      ) : loadError ? (
                        <p className="py-12 text-center text-sm text-red-400">{loadError}</p>
                      ) : winners.length === 0 ? (
                        <div className="mt-8 rounded-2xl border border-stone-800 bg-stone-900/60 p-10 text-center">
                          <Award className="mx-auto h-7 w-7 text-stone-500" />
                          <p className="mt-3 text-sm text-stone-400">
                            No winners match your search.
                          </p>
                        </div>
                      ) : (
                        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                          {winners.map((winner, idx) => (
                            <AwardCard
                              key={winner.id}
                              entry={winner}
                              onSelect={handleSelectEntry}
                              variant="laureate"
                              index={idx}
                            />
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Unlocked Complete Quotes & Highlights Archive at the Very Bottom */}
                    <div className="rounded-3xl border border-stone-200 bg-white p-6 sm:p-10">
                      <div className="flex flex-col gap-5 border-b border-stone-200 pb-6 lg:flex-row lg:items-end lg:justify-between">
                        <div>
                          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700">
                            <CheckCircle2 className="h-4 w-4" />
                            <span>All {AWARD_CATEGORIES.length} Presentations Completed</span>
                          </div>
                          <h2 className="mt-1 font-serif text-3xl font-semibold text-stone-900 sm:text-4xl">
                            Complete Quotes &amp; Moments Archive
                          </h2>
                          <p className="mt-2 max-w-2xl text-sm text-stone-600">
                            Every quote, winner, nominee, and honorable mention across the 2026 season—now searchable below.
                          </p>
                        </div>

                        <div className="relative w-full lg:w-80">
                          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
                          <input
                            type="search"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="Search all quotes, nominees, episodes..."
                            aria-label="Search all quotes"
                            className="w-full rounded-lg border border-stone-300 bg-[#FBF9F5] py-2.5 pl-9 pr-3 text-sm text-stone-900 placeholder:text-stone-400 focus:border-amber-700 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-700/15"
                          />
                        </div>
                      </div>

                      {matchingEntries.length === 0 ? (
                        <div className="mt-8 rounded-2xl border border-stone-200 bg-[#FBF9F5] p-10 text-center">
                          <p className="text-sm text-stone-600">
                            No quotes match “{searchQuery}”.
                          </p>
                        </div>
                      ) : (
                        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
                          {matchingEntries.map((entry, idx) => (
                            <AwardCard
                              key={`home-all-${entry.id}`}
                              entry={entry}
                              onSelect={handleSelectEntry}
                              revealMode
                              index={idx}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </section>
            </motion.main>
          )}
        </AnimatePresence>

        {/* Colorful Editorial Footer */}
        <footer className="border-t border-indigo-200/70 bg-gradient-to-r from-white/95 via-[#FFF8EC]/95 to-[#EFF6FF]/95 backdrop-blur-sm">
          <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-6 py-8 text-xs text-stone-600 lg:flex-row lg:items-center">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-serif text-sm font-semibold text-stone-900">
                The Sideman Awards
              </span>
              <span aria-hidden="true">·</span>
              <span>Annual Quote, Sideman &amp; Moment Archive</span>
            </div>

            <SocialFooter
              shareTitle={
                selectedEntry
                  ? `${selectedEntry.nomineeName} — The Sideman Awards`
                  : activeCategoryMeta
                    ? `${activeCategoryMeta.label} — The Sideman Awards`
                    : route.page === 'winners'
                      ? '2026 Category Winners — The Sideman Awards'
                      : 'The Sideman Awards — 2026 Quote & Moment of the Year'
              }
            />

            <div className="flex flex-wrap items-center gap-6">
              <a
                href="/winners"
                onClick={(e) => navigateTo('/winners', e)}
                className="transition-colors hover:text-stone-900"
              >
                Winners
              </a>
              <a
                href={getCategoryPath('honorable_mentions')}
                onClick={(e) => navigateTo(getCategoryPath('honorable_mentions'), e)}
                className="transition-colors hover:text-stone-900"
              >
                Honorable Mentions
              </a>
              <a
                href="/admin"
                onClick={(e) => navigateTo('/admin', e)}
                className="font-medium text-stone-800 transition-colors hover:text-amber-800"
              >
                Admin Portal
              </a>
            </div>
          </div>
        </footer>

        <EntryDetailModal entry={selectedEntry} onClose={() => handleSelectEntry(null)} />
      </div>
    </MotionConfig>
  );
}
