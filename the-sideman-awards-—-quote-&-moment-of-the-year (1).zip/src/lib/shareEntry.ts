import { AwardCategory, getCategoryPath } from '../types';

export function buildEntryDeepLink(entryId: string, category?: AwardCategory): string {
  const url = new URL(window.location.origin);
  if (category) {
    url.pathname = getCategoryPath(category);
  } else {
    url.pathname = window.location.pathname || '/';
  }
  url.searchParams.set('entry', entryId);
  return url.toString();
}

export async function copyTextToClipboard(text: string): Promise<boolean> {
  if (navigator.clipboard && window.isSecureContext) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fall through to execCommand fallback
    }
  }

  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.top = '-9999px';
    textarea.style.left = '-9999px';
    document.body.appendChild(textarea);
    textarea.select();
    textarea.setSelectionRange(0, text.length);
    const copied = document.execCommand('copy');
    document.body.removeChild(textarea);
    return copied;
  } catch {
    return false;
  }
}

export async function copyEntryDeepLink(
  entryId: string,
  category?: AwardCategory
): Promise<boolean> {
  const deepLink = buildEntryDeepLink(entryId, category);
  return copyTextToClipboard(deepLink);
}
