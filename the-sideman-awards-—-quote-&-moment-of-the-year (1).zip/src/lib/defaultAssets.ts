import heroAwardsStage from '../assets/images/hero_awards_stage_1794599760704.jpg';
import nomineePortraitOne from '../assets/images/nominee_portrait_one_1794599761778.jpg';
import nomineePortraitTwo from '../assets/images/nominee_portrait_two_1794599762097.jpg';
import nomineePortraitThree from '../assets/images/nominee_portrait_three_1794599762777.jpg';
import momentStageSpotlight from '../assets/images/moment_stage_spotlight_1794599762713.jpg';

export interface PresetAsset {
  key: string;
  label: string;
  src: string;
}

export const PRESET_ASSETS: PresetAsset[] = [
  {
    key: 'preset:portrait-1',
    label: 'Studio Portrait I',
    src: nomineePortraitOne,
  },
  {
    key: 'preset:portrait-2',
    label: 'Lounge Candid II',
    src: nomineePortraitTwo,
  },
  {
    key: 'preset:portrait-3',
    label: 'Editorial Frame III',
    src: nomineePortraitThree,
  },
  {
    key: 'preset:moment-1',
    label: 'Table Spotlight',
    src: momentStageSpotlight,
  },
  {
    key: 'preset:hero',
    label: 'Awards Podium',
    src: heroAwardsStage,
  },
];

export const HERO_STAGE_IMAGE = heroAwardsStage;

export function resolveAwardImage(imageUrl?: string | null): string {
  if (!imageUrl) return '';
  const match = PRESET_ASSETS.find((item) => item.key === imageUrl);
  if (match) return match.src;
  return imageUrl;
}
