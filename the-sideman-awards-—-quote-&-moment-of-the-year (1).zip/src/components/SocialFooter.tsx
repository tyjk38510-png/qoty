import { useEffect, useState } from 'react';
import { Check } from 'lucide-react';
import { copyTextToClipboard } from '../lib/shareEntry';

interface SocialFooterProps {
  shareTitle?: string;
  shareUrl?: string;
}

type SocialPlatform = 'twitter' | 'instagram' | 'tiktok';

function TwitterIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className="h-4 w-4 shrink-0"
      aria-hidden="true"
    >
      <path d="M22.46 6c-.77.35-1.6.58-2.46.69a4.3 4.3 0 0 0 1.88-2.37 8.59 8.59 0 0 1-2.72 1.04 4.28 4.28 0 0 0-7.29 3.9A12.14 12.14 0 0 1 3.04 4.8a4.28 4.28 0 0 0 1.32 5.71 4.24 4.24 0 0 1-1.94-.54v.05a4.28 4.28 0 0 0 3.43 4.2 4.3 4.3 0 0 1-1.93.07 4.28 4.28 0 0 0 4 2.97A8.59 8.59 0 0 1 2 19.07a12.11 12.11 0 0 0 6.56 1.92c7.88 0 12.19-6.53 12.19-12.19 0-.19 0-.37-.01-.56A8.72 8.72 0 0 0 22.46 6Z" />
    </svg>
  );
}

function InstagramIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-4 w-4 shrink-0"
      aria-hidden="true"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

function TikTokIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      className="h-4 w-4 shrink-0"
      aria-hidden="true"
    >
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.2a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.81a8.26 8.26 0 0 0 4.76 1.5v-3.4a4.85 4.85 0 0 1-1-.22Z" />
    </svg>
  );
}

export function SocialFooter({ shareTitle, shareUrl }: SocialFooterProps) {
  const [copiedPlatform, setCopiedPlatform] = useState<SocialPlatform | null>(null);

  useEffect(() => {
    if (!copiedPlatform) return;
    const timer = window.setTimeout(() => setCopiedPlatform(null), 2600);
    return () => window.clearTimeout(timer);
  }, [copiedPlatform]);

  const resolvedUrl =
    shareUrl || (typeof window !== 'undefined' ? window.location.href : '');
  const resolvedTitle =
    shareTitle || 'The Sideman Awards — 2026 Quote & Moment of the Year';

  const twitterShareHref = `https://twitter.com/intent/tweet?text=${encodeURIComponent(
    `${resolvedTitle} — check out the nominees & winners!`
  )}&url=${encodeURIComponent(resolvedUrl)}`;

  async function handleCopyForPlatform(platform: SocialPlatform) {
    const caption = `${resolvedTitle}\n${resolvedUrl}`;
    const copied = await copyTextToClipboard(caption);
    if (copied) {
      setCopiedPlatform(platform);
    }
  }

  return (
    <div className="flex flex-col items-start gap-2.5 sm:items-center">
      <div className="flex flex-wrap items-center gap-2">
        <span className="mr-1 text-xs font-medium text-stone-500 whitespace-nowrap">
          Share on social:
        </span>

        <a
          href={twitterShareHref}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Share The Sideman Awards on Twitter"
          className="inline-flex items-center gap-2 rounded-lg border border-stone-200 bg-[#FBF9F5] px-3 py-1.5 text-xs font-medium text-stone-700 transition-all duration-150 hover:-translate-y-0.5 hover:border-sky-300 hover:bg-sky-50 hover:text-sky-800 whitespace-nowrap shrink-0"
        >
          <TwitterIcon />
          <span>Twitter</span>
        </a>

        <a
          href="https://www.instagram.com/"
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => handleCopyForPlatform('instagram')}
          aria-label="Copy link for Instagram and open Instagram"
          className="inline-flex items-center gap-2 rounded-lg border border-stone-200 bg-[#FBF9F5] px-3 py-1.5 text-xs font-medium text-stone-700 transition-all duration-150 hover:-translate-y-0.5 hover:border-rose-300 hover:bg-rose-50 hover:text-rose-800 whitespace-nowrap shrink-0"
        >
          <InstagramIcon />
          <span>Instagram</span>
        </a>

        <a
          href="https://www.tiktok.com/"
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => handleCopyForPlatform('tiktok')}
          aria-label="Copy link for TikTok and open TikTok"
          className="inline-flex items-center gap-2 rounded-lg border border-stone-200 bg-[#FBF9F5] px-3 py-1.5 text-xs font-medium text-stone-700 transition-all duration-150 hover:-translate-y-0.5 hover:border-stone-400 hover:bg-stone-100 hover:text-stone-900 whitespace-nowrap shrink-0"
        >
          <TikTokIcon />
          <span>TikTok</span>
        </a>
      </div>

      {copiedPlatform && (
        <p
          role="status"
          aria-live="polite"
          className="inline-flex items-center gap-1.5 text-[11px] font-medium text-emerald-700"
        >
          <Check className="h-3.5 w-3.5" />
          <span>
            Caption &amp; link copied for{' '}
            {copiedPlatform === 'instagram' ? 'Instagram' : 'TikTok'}
          </span>
        </p>
      )}
    </div>
  );
}
