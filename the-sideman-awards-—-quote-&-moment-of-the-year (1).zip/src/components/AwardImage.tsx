import { useState } from 'react';
import { Award, Quote } from 'lucide-react';
import { resolveAwardImage } from '../lib/defaultAssets';

interface AwardImageProps {
  src?: string;
  alt: string;
  fallbackLabel: string;
  aspectClassName?: string;
  className?: string;
  isMoment?: boolean;
}

export function AwardImage({
  src,
  alt,
  fallbackLabel,
  aspectClassName = 'aspect-[4/3]',
  className = '',
  isMoment = false,
}: AwardImageProps) {
  const [hasError, setHasError] = useState(false);
  const resolved = resolveAwardImage(src);

  const initials = fallbackLabel
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((word) => word[0]?.toUpperCase() || '')
    .join('');

  return (
    <div
      className={`relative overflow-hidden bg-stone-200/70 ${aspectClassName} ${className}`}
    >
      {resolved && !hasError ? (
        <img
          src={resolved}
          alt={alt}
          referrerPolicy="no-referrer"
          onError={() => setHasError(true)}
          className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105 motion-reduce:transition-none motion-reduce:group-hover:scale-100"
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-stone-200 via-stone-100 to-amber-50/70 p-6 text-stone-600">
          <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full border border-stone-300/80 bg-white/80 text-stone-700">
            {isMoment ? <Award className="h-5 w-5" /> : <Quote className="h-5 w-5" />}
          </div>
          <span className="font-serif text-xl font-semibold tracking-tight text-stone-800">
            {initials || 'SA'}
          </span>
          <span className="mt-1 text-center text-xs text-stone-500 line-clamp-1">
            {fallbackLabel}
          </span>
        </div>
      )}
    </div>
  );
}
