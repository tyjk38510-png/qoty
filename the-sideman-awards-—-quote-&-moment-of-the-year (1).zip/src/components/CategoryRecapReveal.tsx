import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowLeft,
  ArrowRight,
  Clock,
  FastForward,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Trophy,
} from 'lucide-react';
import { AwardCategory, AwardEntry, CATEGORY_THEMES } from '../types';
import { AwardImage } from './AwardImage';

interface CategoryRecapRevealProps {
  category: AwardCategory;
  categoryLabel: string;
  entries: AwardEntry[];
  hasCompletedBefore?: boolean;
  onComplete: () => void;
  onSelectEntry: (entry: AwardEntry) => void;
}

const NOMINEE_DURATION_MS = 30000;
const WINNER_DURATION_MS = 32000;

export function CategoryRecapReveal({
  category,
  categoryLabel,
  entries,
  hasCompletedBefore = false,
  onComplete,
  onSelectEntry,
}: CategoryRecapRevealProps) {
  // Order: Nominees first -> Winner LAST as the YouTube Recap climax
  const orderedEntries = useMemo(() => {
    const nonWinners = entries.filter((e) => e.tier !== 'winner');
    const winnerList = entries.filter((e) => e.tier === 'winner');
    return [...nonWinners, ...winnerList];
  }, [entries]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const currentEntry = orderedEntries[currentIndex];
  const isLastSlide = currentIndex >= orderedEntries.length - 1;
  const isWinnerSlide = currentEntry?.tier === 'winner';
  const durationMs = isWinnerSlide ? WINNER_DURATION_MS : NOMINEE_DURATION_MS;

  const [remainingMs, setRemainingMs] = useState(durationMs);
  const lastTickRef = useRef<number>(Date.now());
  const theme = CATEGORY_THEMES[category];

  // Reset to first nominee whenever category changes
  useEffect(() => {
    setCurrentIndex(0);
    setIsPaused(false);
  }, [category]);

  // Reset slide countdown whenever the active slide or its duration changes
  useEffect(() => {
    setRemainingMs(durationMs);
    lastTickRef.current = Date.now();
  }, [category, currentIndex, durationMs]);

  const advanceOrFinish = useCallback(() => {
    if (isLastSlide) {
      onComplete();
    } else {
      setCurrentIndex((prev) => prev + 1);
    }
  }, [isLastSlide, onComplete]);

  useEffect(() => {
    if (orderedEntries.length === 0) {
      onComplete();
      return;
    }
    if (isPaused) return;

    lastTickRef.current = Date.now();
    const interval = window.setInterval(() => {
      const now = Date.now();
      const delta = now - lastTickRef.current;
      lastTickRef.current = now;

      setRemainingMs((prev) => {
        const next = Math.max(0, prev - delta);
        return next;
      });
    }, 200);

    return () => window.clearInterval(interval);
  }, [isPaused, onComplete, orderedEntries.length]);

  useEffect(() => {
    if (!isPaused && orderedEntries.length > 0 && remainingMs <= 0) {
      advanceOrFinish();
    }
  }, [advanceOrFinish, isPaused, orderedEntries.length, remainingMs]);

  if (!currentEntry) return null;

  const progressRatio = Math.min(1, Math.max(0, 1 - remainingMs / durationMs));
  const secondsLeft = Math.max(1, Math.ceil(remainingMs / 1000));
  const nomineeOnlyCount = orderedEntries.filter((e) => e.tier !== 'winner').length;
  const slideBadge =
    currentEntry.tier === 'winner'
      ? `2026 Winner · ${categoryLabel}`
      : currentEntry.tier === 'honorable_mention'
        ? `Honorable Mention ${currentIndex + 1} of ${orderedEntries.length}`
        : `Nominee ${currentIndex + 1} of ${nomineeOnlyCount}`;

  return (
    <div className="relative z-10 py-6">
      {/* Top Recap Story Progress Segments */}
      <div className="mx-auto max-w-4xl">
        <div className="flex flex-wrap items-center gap-1.5">
          {orderedEntries.map((item, idx) => {
            const isPast = idx < currentIndex;
            const isCurrent = idx === currentIndex;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                aria-label={`Jump to ${item.nomineeName}`}
                className="group relative h-2 min-w-[12px] flex-1 overflow-hidden rounded-full bg-black/15"
              >
                {isPast && (
                  <span
                    className={`absolute inset-0 rounded-full ${
                      item.tier === 'winner' ? 'bg-amber-500' : theme.ctaBg
                    }`}
                  />
                )}
                {isCurrent && (
                  <span
                    style={{
                      transform: `scaleX(${progressRatio})`,
                      transformOrigin: 'left center',
                    }}
                    className={`absolute inset-0 rounded-full transition-transform duration-200 ease-linear ${
                      item.tier === 'winner' ? 'bg-amber-500' : theme.ctaBg
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Recap Controls Row */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setIsPaused((prev) => !prev)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300/90 bg-white/95 px-3 py-1.5 text-xs font-medium text-stone-800 transition-colors hover:bg-white"
            >
              {isPaused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
              {isPaused ? 'Resume' : 'Pause'}
            </button>
            <button
              type="button"
              disabled={currentIndex === 0}
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              aria-label="Previous nominee"
              className="inline-flex items-center justify-center rounded-lg border border-stone-300/90 bg-white/95 p-1.5 text-stone-700 transition-colors hover:bg-white disabled:opacity-40"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={advanceOrFinish}
              aria-label={isLastSlide ? 'Finish presentation' : 'Next nominee'}
              className="inline-flex items-center justify-center rounded-lg border border-stone-300/90 bg-white/95 p-1.5 text-stone-700 transition-colors hover:bg-white"
            >
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setCurrentIndex(0);
                setRemainingMs(durationMs);
                setIsPaused(false);
              }}
              aria-label="Restart recap"
              className="inline-flex items-center gap-1 rounded-lg border border-stone-300/90 bg-white/95 px-2.5 py-1.5 text-xs font-medium text-stone-700 transition-colors hover:bg-white"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Restart
            </button>
          </div>

          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300/80 bg-white/90 px-3 py-1.5 font-mono text-xs font-medium text-stone-700 tabular-nums">
              <Clock className="h-3.5 w-3.5 text-stone-500" />
              {isPaused ? `Paused · ${secondsLeft}s` : `${secondsLeft}s`}
            </span>

            {hasCompletedBefore && (
              <button
                type="button"
                onClick={onComplete}
                className={`inline-flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-medium text-white transition-colors ${theme.ctaBg} ${theme.ctaHover}`}
              >
                <FastForward className="h-3.5 w-3.5" />
                Show All At Once
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Sequential Nominee -> Winner Reveal Stage with Clear Fadeaway Transition */}
      <div className="mx-auto mt-8 max-w-4xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentEntry.id}
            initial={{ opacity: 0, y: 28, scale: 0.96, filter: 'blur(4px)' }}
            animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -24, scale: 0.92, filter: 'blur(8px)' }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            onClick={() => onSelectEntry(currentEntry)}
            className={`group cursor-pointer overflow-hidden rounded-3xl border shadow-2xl transition-shadow duration-300 ${
              isWinnerSlide
                ? `${theme.laureateBg} ${theme.laureateBorder} text-white ring-2 ring-amber-400/60`
                : `bg-white ${theme.cardBorder} text-stone-900`
            }`}
          >
            <div className="grid grid-cols-1 md:grid-cols-12">
              <div className="relative md:col-span-5">
                <AwardImage
                  src={currentEntry.imageUrl}
                  alt={currentEntry.nomineeName}
                  fallbackLabel={currentEntry.nomineeName}
                  aspectClassName="aspect-[4/3] md:aspect-auto md:h-full md:min-h-[340px]"
                  isMoment={currentEntry.category === 'moment_of_the_year'}
                />
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs font-medium text-white">
                  <span className="inline-flex items-center gap-1.5">
                    {isWinnerSlide && <Trophy className="h-4 w-4 text-amber-400" />}
                    {slideBadge}
                  </span>
                  <span className="font-mono tabular-nums">{currentEntry.year}</span>
                </div>
              </div>

              <div className="flex flex-col justify-between p-7 sm:p-10 md:col-span-7">
                <div>
                  <div
                    className={`text-xs font-semibold ${
                      isWinnerSlide ? 'text-amber-400' : theme.eyebrowText
                    }`}
                  >
                    {isWinnerSlide ? 'Grand Finale Reveal · Official Winner' : 'Nominee Spotlight'}
                  </div>

                  <h2
                    className={`mt-2 font-serif text-4xl font-semibold leading-tight tracking-tight ${
                      isWinnerSlide ? 'text-white' : theme.headingText
                    }`}
                  >
                    {currentEntry.nomineeName}
                  </h2>

                  {/* Their Signature Thing */}
                  <div
                    className={`mt-4 rounded-xl border px-4 py-3 ${
                      isWinnerSlide ? theme.thingBoxDark : theme.thingBoxLight
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs font-semibold">
                      <Sparkles className="h-3.5 w-3.5 shrink-0" />
                      <span className={isWinnerSlide ? theme.thingLabelDark : theme.thingLabelLight}>
                        {currentEntry.nomineeName}’s Thing
                      </span>
                    </div>
                    <p className="mt-1 text-sm font-medium leading-snug">
                      {currentEntry.signatureThing || currentEntry.title}
                    </p>
                  </div>

                  <blockquote
                    className={`mt-5 font-serif text-2xl italic leading-relaxed ${
                      isWinnerSlide ? 'text-stone-100' : 'text-stone-800'
                    }`}
                  >
                    “{currentEntry.quote}”
                  </blockquote>
                </div>

                <div
                  className={`mt-6 flex items-center justify-between border-t pt-4 text-xs ${
                    isWinnerSlide
                      ? 'border-white/15 text-stone-300'
                      : 'border-stone-200 text-stone-500'
                  }`}
                >
                  <span>
                    {currentEntry.title} · {currentEntry.episode}
                  </span>
                  <span
                    className={`font-semibold ${
                      isWinnerSlide ? 'text-amber-300' : theme.eyebrowText
                    }`}
                  >
                    {isLastSlide
                      ? `Unlocks full category in ${secondsLeft}s`
                      : `Next nominee in ${secondsLeft}s`}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
