import { ChangeEvent, FormEvent, useState } from 'react';
import {
  ArrowLeft,
  Check,
  Code2,
  Eye,
  EyeOff,
  Lock,
  LogOut,
  Pencil,
  Plus,
  Trash2,
  Trophy,
  Upload,
} from 'lucide-react';
import { PRESET_ASSETS } from '../lib/defaultAssets';
import {
  AWARD_CATEGORIES,
  AwardCategory,
  AwardEntry,
  AwardEntryInput,
  AwardTier,
  CATEGORY_THEMES,
} from '../types';
import { AwardImage } from './AwardImage';

interface AdminDashboardProps {
  entries: AwardEntry[];
  isAuthenticated: boolean;
  adminUsername: string | null;
  authToken: string | null;
  onLoginSuccess: (username: string, token: string) => void;
  onLogout: () => void;
  onEntriesChange: (entries: AwardEntry[]) => void;
  onBackToSite: () => void;
}

interface SimpleCategoryForm {
  tier: AwardTier;
  nomineeName: string;
  signatureThing: string;
  quote: string;
  episode: string;
  imageUrl: string;
}

const EMPTY_SIMPLE_FORM: SimpleCategoryForm = {
  tier: 'nominee',
  nomineeName: '',
  signatureThing: '',
  quote: '',
  episode: '',
  imageUrl: 'preset:portrait-1',
};

export function AdminDashboard({
  entries,
  isAuthenticated,
  adminUsername,
  authToken,
  onLoginSuccess,
  onLogout,
  onEntriesChange,
  onBackToSite,
}: AdminDashboardProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const [activeCategory, setActiveCategory] = useState<AwardCategory>('quote_of_the_year');
  const [form, setForm] = useState<SimpleCategoryForm>(EMPTY_SIMPLE_FORM);
  const [editingEntry, setEditingEntry] = useState<AwardEntry | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [showBulkCode, setShowBulkCode] = useState(false);
  const [bulkCode, setBulkCode] = useState('');
  const [isBulkImporting, setIsBulkImporting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const authHeaders = (): Record<string, string> => {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (authToken) {
      headers.Authorization = `Bearer ${authToken}`;
    }
    return headers;
  };

  async function handleLogin(e: FormEvent) {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setLoginError(data.error || 'Authentication failed.');
        return;
      }
      setPassword('');
      onLoginSuccess(data.username, data.token);
    } catch {
      setLoginError('Unable to reach the authentication server.');
    } finally {
      setIsLoggingIn(false);
    }
  }

  function handleSelectCategorySession(categoryId: AwardCategory) {
    setActiveCategory(categoryId);
    setEditingEntry(null);
    setForm({
      ...EMPTY_SIMPLE_FORM,
      tier: categoryId === 'honorable_mentions' ? 'honorable_mention' : 'nominee',
    });
    setStatusMessage(null);
  }

  async function handleFileUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setStatusMessage(null);

    if (file.size > 4.5 * 1024 * 1024) {
      setStatusMessage({ type: 'error', text: 'Photo must be smaller than 4.5 MB.' });
      return;
    }

    setIsUploading(true);
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
      });

      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ dataUrl }),
      });
      const data = await res.json();
      if (!res.ok) {
        setStatusMessage({ type: 'error', text: data.error || 'Photo upload failed.' });
        return;
      }
      setForm((prev) => ({ ...prev, imageUrl: data.url }));
      setStatusMessage({ type: 'success', text: 'Photo uploaded and ready to save.' });
    } catch {
      setStatusMessage({ type: 'error', text: 'Could not upload the selected image.' });
    } finally {
      setIsUploading(false);
      e.target.value = '';
    }
  }

  async function handleSubmitEntry(e: FormEvent) {
    e.preventDefault();
    setStatusMessage(null);
    setIsSubmitting(true);

    const categoryMeta =
      AWARD_CATEGORIES.find((c) => c.id === activeCategory) || AWARD_CATEGORIES[0];

    const resolvedTitle =
      editingEntry?.title ||
      form.signatureThing.trim().slice(0, 60) ||
      `${form.nomineeName.trim()} — ${categoryMeta.shortLabel}`;

    const payload: AwardEntryInput = {
      category: activeCategory,
      tier:
        activeCategory === 'honorable_mentions'
          ? 'honorable_mention'
          : form.tier === 'winner'
            ? 'winner'
            : 'nominee',
      nomineeName: form.nomineeName.trim(),
      signatureThing: form.signatureThing.trim(),
      title: resolvedTitle,
      quote: form.quote.trim(),
      context: editingEntry?.context || '',
      episode: form.episode.trim() || '2026 Season',
      year: editingEntry?.year || 2026,
      imageUrl: form.imageUrl.trim(),
    };

    try {
      const endpoint = editingEntry ? `/api/entries/${editingEntry.id}` : '/api/entries';
      const method = editingEntry ? 'PUT' : 'POST';
      const res = await fetch(endpoint, {
        method,
        headers: authHeaders(),
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setStatusMessage({ type: 'error', text: data.error || 'Failed to save entry.' });
        return;
      }
      onEntriesChange(data.entries);
      setForm({
        ...EMPTY_SIMPLE_FORM,
        tier: activeCategory === 'honorable_mentions' ? 'honorable_mention' : 'nominee',
      });
      setEditingEntry(null);
      setStatusMessage({
        type: 'success',
        text: editingEntry
          ? `Updated ${payload.nomineeName} in ${categoryMeta.label}.`
          : `Added ${payload.nomineeName} to ${categoryMeta.label}.`,
      });
    } catch {
      setStatusMessage({ type: 'error', text: 'Network error while saving entry.' });
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handlePromoteWinner(entry: AwardEntry) {
    setStatusMessage(null);
    try {
      const res = await fetch(`/api/entries/${entry.id}/promote`, {
        method: 'POST',
        headers: authHeaders(),
      });
      const data = await res.json();
      if (!res.ok) {
        setStatusMessage({ type: 'error', text: data.error || 'Unable to promote entry.' });
        return;
      }
      onEntriesChange(data.entries);
      setStatusMessage({
        type: 'success',
        text: `${entry.nomineeName} crowned as Winner.`,
      });
    } catch {
      setStatusMessage({ type: 'error', text: 'Network error while promoting winner.' });
    }
  }

  async function handleDeleteEntry(entry: AwardEntry) {
    setStatusMessage(null);
    try {
      const res = await fetch(`/api/entries/${entry.id}`, {
        method: 'DELETE',
        headers: authHeaders(),
      });
      const data = await res.json();
      if (!res.ok) {
        setStatusMessage({ type: 'error', text: data.error || 'Unable to delete entry.' });
        return;
      }
      onEntriesChange(data.entries);
      if (editingEntry?.id === entry.id) {
        setEditingEntry(null);
        setForm({
          ...EMPTY_SIMPLE_FORM,
          tier: activeCategory === 'honorable_mentions' ? 'honorable_mention' : 'nominee',
        });
      }
      setStatusMessage({ type: 'success', text: `Removed "${entry.nomineeName}".` });
    } catch {
      setStatusMessage({ type: 'error', text: 'Network error while deleting entry.' });
    }
  }

  async function handleBulkImport(e: FormEvent) {
    e.preventDefault();
    setStatusMessage(null);

    let parsedRaw: unknown;
    try {
      parsedRaw = JSON.parse(bulkCode);
    } catch {
      setStatusMessage({
        type: 'error',
        text: 'Invalid JSON syntax. Paste an array of nominee objects.',
      });
      return;
    }

    if (!Array.isArray(parsedRaw) || parsedRaw.length === 0) {
      setStatusMessage({
        type: 'error',
        text: 'Paste a non-empty JSON array of nominees.',
      });
      return;
    }

    const categoryMeta =
      AWARD_CATEGORIES.find((c) => c.id === activeCategory) || AWARD_CATEGORIES[0];

    const normalizedItems = parsedRaw.map((raw) => {
      const item = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
      const nomineeName = String(item.nomineeName || '').trim();
      const signatureThing = String(item.signatureThing || '').trim();
      const quote = String(item.quote || '').trim();
      const rawTier = String(item.tier || 'nominee');
      return {
        category: activeCategory,
        tier:
          activeCategory === 'honorable_mentions'
            ? 'honorable_mention'
            : rawTier === 'winner'
              ? 'winner'
              : 'nominee',
        nomineeName,
        signatureThing: signatureThing || nomineeName,
        title: String(item.title || '').trim() || signatureThing || `${nomineeName} — ${categoryMeta.shortLabel}`,
        quote,
        context: String(item.context || '').trim(),
        episode: String(item.episode || '').trim() || '2026 Season',
        year: Number(item.year) || 2026,
        imageUrl: String(item.imageUrl || '').trim() || 'preset:portrait-1',
      };
    });

    setIsBulkImporting(true);
    try {
      const res = await fetch('/api/entries/bulk', {
        method: 'POST',
        headers: authHeaders(),
        body: JSON.stringify({ items: normalizedItems }),
      });
      const data = await res.json();
      if (!res.ok) {
        setStatusMessage({ type: 'error', text: data.error || 'Bulk import failed.' });
        return;
      }
      onEntriesChange(data.entries);
      setBulkCode('');
      setShowBulkCode(false);
      setStatusMessage({
        type: 'success',
        text: `Added ${data.addedCount} nominees into ${categoryMeta.label}.`,
      });
    } catch {
      setStatusMessage({ type: 'error', text: 'Network error during bulk import.' });
    } finally {
      setIsBulkImporting(false);
    }
  }

  function startEditing(entry: AwardEntry) {
    setActiveCategory(entry.category);
    setEditingEntry(entry);
    setForm({
      tier: entry.tier,
      nomineeName: entry.nomineeName,
      signatureThing: entry.signatureThing || '',
      quote: entry.quote,
      episode: entry.episode,
      imageUrl: entry.imageUrl,
    });
    setStatusMessage(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  if (!isAuthenticated) {
    return (
      <main className="mx-auto flex min-h-[calc(100vh-80px)] max-w-7xl items-center justify-center px-6 py-16">
        <div className="w-full max-w-md rounded-2xl border border-stone-200 bg-white p-8 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-stone-900 text-amber-400">
              <Lock className="h-5 w-5" />
            </span>
            <button
              type="button"
              onClick={onBackToSite}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-600 transition-colors hover:text-stone-900"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to Awards
            </button>
          </div>

          <h1 className="mt-6 font-serif text-3xl font-semibold text-stone-900">
            Admin Sign In
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-stone-600">
            Sign in to add nominees, quotes, and photos for each award category.
          </p>

          <form onSubmit={handleLogin} className="mt-6 space-y-4">
            <div>
              <label htmlFor="admin-username" className="block text-xs font-medium text-stone-700">
                Username
              </label>
              <input
                id="admin-username"
                type="text"
                required
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="ben"
                className="mt-1.5 w-full rounded-lg border border-stone-300 bg-[#FBF9F5] px-3.5 py-2.5 text-sm text-stone-900 transition-colors focus:border-amber-700 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-700/20"
              />
            </div>

            <div>
              <label htmlFor="admin-password" className="block text-xs font-medium text-stone-700">
                Password
              </label>
              <div className="relative mt-1.5">
                <input
                  id="admin-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password"
                  className="w-full rounded-lg border border-stone-300 bg-[#FBF9F5] py-2.5 pl-3.5 pr-11 text-sm text-stone-900 transition-colors focus:border-amber-700 focus:bg-white focus:outline-none focus:ring-2 focus:ring-amber-700/20"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-md p-1.5 text-stone-500 transition-colors hover:text-stone-900"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {loginError && (
              <div
                role="alert"
                className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-800"
              >
                {loginError}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoggingIn}
              className="flex w-full items-center justify-center rounded-lg bg-stone-900 px-4 py-2.5 text-sm font-medium text-white transition-colors duration-150 hover:bg-stone-800 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isLoggingIn ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 border-t border-stone-200 pt-4 text-xs leading-relaxed text-stone-500">
            Admin accounts: <span className="font-mono text-stone-800">ben</span> /{' '}
            <span className="font-mono text-stone-800">12345</span> or{' '}
            <span className="font-mono text-stone-800">admin</span> /{' '}
            <span className="font-mono text-stone-800">sideman2026</span>.
          </div>
        </div>
      </main>
    );
  }

  const categoryMeta =
    AWARD_CATEGORIES.find((cat) => cat.id === activeCategory) || AWARD_CATEGORIES[0];
  const categoryTheme = CATEGORY_THEMES[activeCategory];
  const categoryEntries = entries
    .filter((item) => item.category === activeCategory)
    .sort((a, b) => {
      if (a.tier === 'winner' && b.tier !== 'winner') return -1;
      if (b.tier === 'winner' && a.tier !== 'winner') return 1;
      return 0;
    });

  return (
    <main className="mx-auto max-w-7xl px-6 py-10">
      {/* Simple Top Header */}
      <div className="flex flex-col gap-4 border-b border-stone-200 pb-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <p className="text-xs text-stone-500">
            Signed in as <span className="font-medium text-stone-900">{adminUsername || 'admin'}</span>
          </p>
          <h1 className="mt-1 font-serif text-3xl font-semibold text-stone-900">
            Simple Admin Studio
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBackToSite}
            className="inline-flex items-center gap-2 rounded-lg border border-stone-300 bg-white px-4 py-2 text-xs font-medium text-stone-800 transition-colors hover:bg-stone-50 whitespace-nowrap shrink-0"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            View Site
          </button>
          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-2 rounded-lg bg-stone-900 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-stone-800 whitespace-nowrap shrink-0"
          >
            <LogOut className="h-3.5 w-3.5" />
            Sign Out
          </button>
        </div>
      </div>

      {/* Category Session Selector: Separate Input Session Per Category */}
      <div className="mt-6">
        <p className="mb-2.5 text-xs font-medium text-stone-600">
          Pick a category session to add or manage its nominees:
        </p>
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4 lg:grid-cols-7">
          {AWARD_CATEGORIES.map((cat) => {
            const theme = CATEGORY_THEMES[cat.id];
            const isSelected = activeCategory === cat.id;
            const count = entries.filter((e) => e.category === cat.id).length;

            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleSelectCategorySession(cat.id)}
                className={`flex flex-col items-start rounded-xl border p-3 text-left transition-all duration-150 ${
                  isSelected
                    ? `${theme.bandBg} ${theme.bandBorder} ring-2 ring-stone-900`
                    : 'border-stone-200 bg-white hover:border-stone-300 hover:bg-stone-50'
                }`}
              >
                <div className="flex w-full items-center justify-between">
                  <span className={`h-2.5 w-2.5 rounded-full ${theme.swatchDot}`} />
                  <span className="font-mono text-[11px] tabular-nums text-stone-500">
                    {count}
                  </span>
                </div>
                <span
                  className={`mt-2 text-xs font-semibold leading-snug ${
                    isSelected ? theme.headingText : 'text-stone-800'
                  }`}
                >
                  {cat.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {statusMessage && (
        <div
          role="status"
          className={`mt-6 flex items-center justify-between rounded-xl border px-4 py-3 text-sm ${
            statusMessage.type === 'success'
              ? 'border-emerald-200 bg-emerald-50 text-emerald-900'
              : 'border-red-200 bg-red-50 text-red-900'
          }`}
        >
          <span>{statusMessage.text}</span>
          <button
            type="button"
            onClick={() => setStatusMessage(null)}
            className="text-xs font-medium underline underline-offset-2"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Dedicated Category Session Workspace */}
      <section
        className={`mt-6 rounded-2xl border p-6 sm:p-8 ${categoryTheme.bandBg} ${categoryTheme.bandBorder}`}
      >
        <div className="flex flex-col gap-3 border-b border-black/10 pb-5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className={`text-xs font-semibold ${categoryTheme.eyebrowText}`}>
              Category Session · Unlimited Nominees Supported
            </p>
            <h2 className={`mt-0.5 font-serif text-3xl font-semibold ${categoryTheme.headingText}`}>
              {categoryMeta.label}
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <p className={`text-xs sm:max-w-xs sm:text-right ${categoryTheme.mutedText}`}>
              {categoryMeta.description}
            </p>
            <button
              type="button"
              onClick={() => setShowBulkCode((prev) => !prev)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-black/15 bg-white px-3 py-2 text-xs font-medium text-stone-800 transition-colors hover:bg-stone-50 whitespace-nowrap shrink-0"
            >
              <Code2 className="h-3.5 w-3.5" />
              {showBulkCode ? 'Close Code Input' : 'Add via Code (JSON)'}
            </button>
          </div>
        </div>

        {showBulkCode && (
          <form
            onSubmit={handleBulkImport}
            className="mt-5 rounded-2xl border border-black/10 bg-white p-5 shadow-sm"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label
                htmlFor="bulk-nominees-json"
                className="text-xs font-semibold text-stone-900"
              >
                Paste Nominees JSON Array for {categoryMeta.label} (Unlimited Count)
              </label>
              <button
                type="button"
                onClick={() =>
                  setBulkCode(
                    JSON.stringify(
                      [
                        {
                          nomineeName: 'New Nominee',
                          signatureThing: 'Their signature habit or trait',
                          quote: 'Their memorable quote goes here.',
                          episode: 'Episode 45',
                          tier: 'nominee',
                        },
                      ],
                      null,
                      2
                    )
                  )
                }
                className="text-xs font-medium text-amber-800 underline underline-offset-2 hover:text-amber-900"
              >
                Insert Template
              </button>
            </div>
            <textarea
              id="bulk-nominees-json"
              rows={6}
              required
              value={bulkCode}
              onChange={(e) => setBulkCode(e.target.value)}
              placeholder='[{"nomineeName": "Alex", "signatureThing": "Always late", "quote": "Traffic was wild."}]'
              className="mt-2.5 w-full rounded-lg border border-stone-300 bg-[#FBF9F5] p-3 font-mono text-xs text-stone-900 focus:border-stone-900 focus:bg-white focus:outline-none"
            />
            <div className="mt-3 flex justify-end">
              <button
                type="submit"
                disabled={isBulkImporting}
                className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-medium text-white transition-colors disabled:opacity-60 ${categoryTheme.ctaBg} ${categoryTheme.ctaHover}`}
              >
                <Plus className="h-3.5 w-3.5" />
                {isBulkImporting ? 'Importing...' : `Import into ${categoryMeta.shortLabel}`}
              </button>
            </div>
          </form>
        )}

        <div className="mt-6 grid grid-cols-1 gap-8 lg:grid-cols-12">
          {/* Left: Simplified Input Form for this Category */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-sm">
              <div className="flex items-center justify-between">
                <h3 className="font-serif text-xl font-semibold text-stone-900">
                  {editingEntry ? `Editing ${editingEntry.nomineeName}` : `Add to ${categoryMeta.shortLabel}`}
                </h3>
                {editingEntry && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingEntry(null);
                      setForm({
                        ...EMPTY_SIMPLE_FORM,
                        tier: activeCategory === 'honorable_mentions' ? 'honorable_mention' : 'nominee',
                      });
                    }}
                    className="text-xs font-medium text-stone-500 hover:text-stone-900"
                  >
                    Cancel
                  </button>
                )}
              </div>

              <form onSubmit={handleSubmitEntry} className="mt-5 space-y-4">
                {categoryMeta.hasWinner && (
                  <div>
                    <span className="block text-xs font-medium text-stone-700">Standing</span>
                    <div className="mt-1.5 grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setForm((prev) => ({ ...prev, tier: 'nominee' }))}
                        className={`rounded-lg border px-3 py-2 text-xs font-medium transition-colors ${
                          form.tier !== 'winner'
                            ? `${categoryTheme.ctaBg} border-transparent text-white`
                            : 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
                        }`}
                      >
                        Nominee
                      </button>
                      <button
                        type="button"
                        onClick={() => setForm((prev) => ({ ...prev, tier: 'winner' }))}
                        className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-2 text-xs font-medium transition-colors ${
                          form.tier === 'winner'
                            ? 'border-amber-500 bg-amber-500 text-stone-950'
                            : 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
                        }`}
                      >
                        <Trophy className="h-3.5 w-3.5" />
                        Winner
                      </button>
                    </div>
                  </div>
                )}

                <div>
                  <label htmlFor="simple-nominee" className="block text-xs font-medium text-stone-700">
                    Nominee Name
                  </label>
                  <input
                    id="simple-nominee"
                    type="text"
                    required
                    value={form.nomineeName}
                    onChange={(e) => setForm((prev) => ({ ...prev, nomineeName: e.target.value }))}
                    placeholder="e.g. Callum Reid"
                    className="mt-1.5 w-full rounded-lg border border-stone-300 bg-[#FBF9F5] px-3 py-2 text-sm text-stone-900 focus:border-stone-900 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="simple-thing" className="block text-xs font-medium text-stone-700">
                    {categoryMeta.thingLabel}
                  </label>
                  <input
                    id="simple-thing"
                    type="text"
                    required
                    value={form.signatureThing}
                    onChange={(e) => setForm((prev) => ({ ...prev, signatureThing: e.target.value }))}
                    placeholder={categoryMeta.thingPlaceholder}
                    className="mt-1.5 w-full rounded-lg border border-stone-300 bg-[#FBF9F5] px-3 py-2 text-sm text-stone-900 focus:border-stone-900 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="simple-quote" className="block text-xs font-medium text-stone-700">
                    Quote / Highlight
                  </label>
                  <textarea
                    id="simple-quote"
                    rows={3}
                    required
                    value={form.quote}
                    onChange={(e) => setForm((prev) => ({ ...prev, quote: e.target.value }))}
                    placeholder="Write the quote or highlight..."
                    className="mt-1.5 w-full rounded-lg border border-stone-300 bg-[#FBF9F5] px-3 py-2 text-sm text-stone-900 focus:border-stone-900 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="simple-episode" className="block text-xs font-medium text-stone-700">
                    Episode / Moment (Optional)
                  </label>
                  <input
                    id="simple-episode"
                    type="text"
                    value={form.episode}
                    onChange={(e) => setForm((prev) => ({ ...prev, episode: e.target.value }))}
                    placeholder="e.g. Episode 42"
                    className="mt-1.5 w-full rounded-lg border border-stone-300 bg-[#FBF9F5] px-3 py-2 text-sm text-stone-900 focus:border-stone-900 focus:bg-white focus:outline-none"
                  />
                </div>

                {/* Simple Photo Picker */}
                <div className="rounded-xl border border-stone-200 bg-[#FBF9F5] p-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-stone-800">Photo</span>
                    <label className="inline-flex cursor-pointer items-center gap-1.5 rounded-lg border border-stone-300 bg-white px-2.5 py-1 text-xs font-medium text-stone-800 hover:bg-stone-50">
                      <Upload className="h-3.5 w-3.5" />
                      {isUploading ? 'Uploading...' : 'Upload'}
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp,image/gif"
                        onChange={handleFileUpload}
                        className="sr-only"
                      />
                    </label>
                  </div>

                  <div className="mt-2.5 flex items-center gap-3">
                    <div className="h-14 w-16 shrink-0 overflow-hidden rounded-lg border border-stone-200">
                      <AwardImage
                        src={form.imageUrl}
                        alt="Preview"
                        fallbackLabel={form.nomineeName || 'Pic'}
                        aspectClassName="h-full w-full"
                      />
                    </div>
                    <div className="min-w-0 flex-1 space-y-1.5">
                      <input
                        type="text"
                        value={form.imageUrl}
                        onChange={(e) => setForm((prev) => ({ ...prev, imageUrl: e.target.value }))}
                        placeholder="Image URL or upload..."
                        aria-label="Image URL"
                        className="w-full rounded-lg border border-stone-300 bg-white px-2.5 py-1.5 text-xs text-stone-900 focus:border-stone-900 focus:outline-none"
                      />
                      <div className="flex flex-wrap gap-1">
                        {PRESET_ASSETS.map((preset) => (
                          <button
                            key={preset.key}
                            type="button"
                            onClick={() => setForm((prev) => ({ ...prev, imageUrl: preset.key }))}
                            className={`rounded px-2 py-0.5 text-[11px] font-medium transition-colors ${
                              form.imageUrl === preset.key
                                ? 'bg-stone-900 text-white'
                                : 'border border-stone-200 bg-white text-stone-600 hover:text-stone-900'
                            }`}
                          >
                            {preset.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting || isUploading}
                  className={`inline-flex w-full items-center justify-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium text-white transition-colors disabled:opacity-60 ${categoryTheme.ctaBg} ${categoryTheme.ctaHover}`}
                >
                  {editingEntry ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                  {isSubmitting
                    ? 'Saving...'
                    : editingEntry
                      ? 'Save Changes'
                      : `Add to ${categoryMeta.shortLabel}`}
                </button>
              </form>
            </div>
          </div>

          {/* Right: Entries inside this Category Session */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl border border-black/10 bg-white p-6 shadow-sm">
              <div className="flex items-center justify-between border-b border-stone-100 pb-4">
                <h3 className="font-serif text-xl font-semibold text-stone-900">
                  {categoryMeta.label} Entries ({categoryEntries.length})
                </h3>
              </div>

              <div className="mt-3 divide-y divide-stone-100">
                {categoryEntries.length === 0 ? (
                  <p className="py-12 text-center text-sm text-stone-500">
                    No entries in {categoryMeta.label} yet. Add the first one on the left.
                  </p>
                ) : (
                  categoryEntries.map((entry) => {
                    const isWinner = entry.tier === 'winner';
                    return (
                      <div
                        key={entry.id}
                        className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between"
                      >
                        <div className="flex min-w-0 items-start gap-3.5">
                          <div className="h-14 w-14 shrink-0 overflow-hidden rounded-lg border border-stone-200">
                            <AwardImage
                              src={entry.imageUrl}
                              alt={entry.nomineeName}
                              fallbackLabel={entry.nomineeName}
                              aspectClassName="h-full w-full"
                            />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 text-xs">
                              <span
                                className={
                                  isWinner
                                    ? 'font-semibold text-amber-700'
                                    : `font-medium ${categoryTheme.eyebrowText}`
                                }
                              >
                                {isWinner
                                  ? 'Winner'
                                  : entry.tier === 'honorable_mention'
                                    ? 'Honorable Mention'
                                    : 'Nominee'}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span className="truncate text-stone-500">{entry.episode}</span>
                            </div>
                            <p className="mt-0.5 truncate text-sm font-semibold text-stone-900">
                              {entry.nomineeName}
                            </p>
                            <p className={`truncate text-xs font-medium ${categoryTheme.eyebrowText}`}>
                              {entry.signatureThing || entry.title}
                            </p>
                            <p className="mt-1 line-clamp-2 font-serif text-sm italic text-stone-600">
                              “{entry.quote}”
                            </p>
                          </div>
                        </div>

                        <div className="flex shrink-0 items-center gap-2">
                          {categoryMeta.hasWinner && !isWinner && (
                            <button
                              type="button"
                              onClick={() => handlePromoteWinner(entry)}
                              className="inline-flex items-center gap-1 rounded-lg border border-amber-300 bg-amber-50 px-2.5 py-1.5 text-xs font-medium text-amber-900 transition-colors hover:bg-amber-100 whitespace-nowrap"
                            >
                              <Trophy className="h-3.5 w-3.5" />
                              Winner
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => startEditing(entry)}
                            aria-label={`Edit ${entry.nomineeName}`}
                            className="inline-flex items-center gap-1 rounded-lg border border-stone-200 bg-white px-2.5 py-1.5 text-xs font-medium text-stone-700 hover:bg-stone-50"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                            Edit
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeleteEntry(entry)}
                            aria-label={`Delete ${entry.nomineeName}`}
                            className="inline-flex items-center justify-center rounded-lg border border-stone-200 bg-white p-1.5 text-stone-500 hover:border-red-200 hover:bg-red-50 hover:text-red-700"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
