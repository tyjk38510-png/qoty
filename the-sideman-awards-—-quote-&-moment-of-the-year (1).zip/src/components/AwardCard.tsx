import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, Check, Share2, Sparkles, Trophy } from 'lucide-react';
import { copyEntryDeepLink } from '../lib/shareEntry';
import { AWARD_CATEGORIES, AwardEntry, CATEGORY_THEMES } from '../types';
import { AwardImage } from './AwardImage';

interface AwardCardProps {
  entry: AwardEntry;
  onSelect: (entry: AwardEntry) => void;
  variant?: 'default' | 'laureate';
  revealMode?: boolean;
  index?: number;
}

export function AwardCard({
  entry,
  onSelect,
  variant = 'default',
  revealMode = false,
  index = 0,
}: AwardCardProps) {
  const [copied, setCopied] = useState(false);
  const categoryMeta = AWARD_CATEGORIES.find((c) => c.id === entry.category);
  const theme = CATEGORY_THEMES[entry.category];
  const isWinner = entry.tier === 'winner';
  const isLaureate = variant === 'laureate' || isWinner;

  useEffect(() => {
    if (!copied) return;
    const timer = window.setTimeout(() => setCopied(false), 2000);
    return () => window.clearTimeout(timer);
  }, [copied]);

  async function handleShareClick(e: React.MouseEvent) {
    e.stopPropagation();
    const ok = await copyEntryDeepLink(entry.id, entry.category);
    if (ok) {
      setCopied(true);
    }
  }

  const tierLabel =
    entry.tier === 'winner'
      ? 'Winner'
      : entry.tier === 'honorable_mention'
        ? 'Honorable Mention'
        : 'Nominee';

  return (
    <motion.article
      initial={revealMode ? { opacity: 0, y: 20, scale: 0.98 } : { opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        duration: 0.35,
        delay: Math.min(index * 0.06, 0.36),
        ease: [0.16, 1, 0.3, 1],
      }}
      onClick={() => onSelect(entry)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onSelect(entry);
        }
      }}
      tabIndex={0}
      role="button"
      aria-label={`View ${entry.nomineeName} — ${entry.title}`}
      className={`group relative flex cursor-pointer flex-col overflow-hidden rounded-xl border text-left transition-all duration-300 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600 focus-visible:ring-offset-2 focus-visible:ring-offset-[#FBF9F5] motion-reduce:transition-none motion-reduce:hover:transform-none hover:-translate-y-1.5 ${
        isLaureate
          ? `${theme.laureateBg} ${theme.laureateBorder} text-stone-100 hover:border-amber-400/70 hover:shadow-[0_24px_48px_-14px_rgba(0,0,0,0.4)]`
          : `bg-white ${theme.cardBorder} ${theme.cardHoverBorder} ${theme.cardShadow} text-[#1C1917]`
      }`}
    >
      <div className="relative">
        <AwardImage
          src={entry.imageUrl}
          alt={`${entry.nomineeName} — ${entry.title}`}
          fallbackLabel={entry.nomineeName}
          aspectClassName={revealMode ? 'aspect-[4/3]' : 'aspect-[4/3]'}
          isMoment={entry.category === 'moment_of_the_year'}
        />
        <div
          className={`pointer-events-none absolute inset-0 bg-gradient-to-t transition-opacity duration-300 ${
            isLaureate
              ? 'from-black/80 via-black/25 to-transparent opacity-85 group-hover:opacity-95'
              : 'from-stone-950/60 via-transparent to-transparent opacity-55 group-hover:opacity-75'
          }`}
        />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between p-4">
          <div className="flex items-center gap-2 text-xs font-medium tracking-wide text-stone-100">
            {isWinner && <Trophy className="h-3.5 w-3.5 text-amber-400" />}
            <span>{tierLabel}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{entry.year}</span>
          </div>
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20 text-white backdrop-blur-sm transition-all duration-200 ease-out group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:bg-amber-500 group-hover:text-stone-950">
            <ArrowUpRight className="h-4 w-4" />
          </span>
        </div>
      </div>

      <div className="flex flex-1 flex-col justify-between p-6">
        <div>
          <div
            className={`mb-2 flex flex-wrap items-center gap-2 text-xs ${
              isLaureate ? 'text-stone-300' : 'text-stone-500'
            }`}
          >
            <span
              className={`font-semibold ${
                isLaureate ? theme.laureateAccentText : theme.eyebrowText
              }`}
            >
              {categoryMeta?.label || entry.category}
            </span>
            <span aria-hidden="true">·</span>
            <span className="truncate">{entry.episode}</span>
          </div>

          <h3
            className={`font-serif text-xl font-semibold leading-snug tracking-tight transition-colors duration-200 ${
              isLaureate
                ? 'text-white group-hover:text-amber-300'
                : `text-stone-900 ${theme.cardTitleHover}`
            }`}
          >
            {entry.title}
          </h3>

          {/* Reveal Nominee & Their Signature Thing */}
          <div
            className={`mt-3 rounded-lg border px-3.5 py-2.5 transition-colors duration-200 ${
              isLaureate ? theme.thingBoxDark : theme.thingBoxLight
            }`}
          >
            <div className="flex items-center gap-1.5 text-[11px] font-semibold">
              <Sparkles className="h-3 w-3 shrink-0" />
              <span className={isLaureate ? theme.thingLabelDark : theme.thingLabelLight}>
                {entry.nomineeName}’s Thing
              </span>
            </div>
            <p className="mt-1 text-xs font-medium leading-snug">
              {entry.signatureThing || entry.title}
            </p>
          </div>

          <blockquote
            className={`mt-3.5 font-serif text-lg italic leading-relaxed ${
              isLaureate ? 'text-stone-100' : 'text-stone-700'
            }`}
          >
            “{entry.quote}”
          </blockquote>

          {revealMode && entry.context && (
            <p
              className={`mt-3 text-xs leading-relaxed ${
                isLaureate ? 'text-stone-300' : 'text-stone-600'
              }`}
            >
              {entry.context}
            </p>
          )}
        </div>

        <div
          className={`mt-5 flex items-center justify-between gap-3 border-t pt-4 text-sm ${
            isLaureate ? 'border-white/15 text-stone-200' : 'border-stone-100 text-stone-700'
          }`}
        >
          <span className="truncate font-semibold">{entry.nomineeName}</span>
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleShareClick}
              onKeyDown={(e) => e.stopPropagation()}
              aria-label={`Copy share link for ${entry.title}`}
              className={`inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-xs font-medium transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600 whitespace-nowrap shrink-0 ${
                copied
                  ? isLaureate
                    ? 'bg-emerald-900/70 text-emerald-200'
                    : 'bg-emerald-50 text-emerald-800'
                  : isLaureate
                    ? 'text-stone-200 hover:bg-white/10 hover:text-amber-300'
                    : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
              }`}
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5" />
                  <span>Copied</span>
                </>
              ) : (
                <>
                  <Share2 className="h-3.5 w-3.5" />
                  <span>Share</span>
                </>
              )}
            </button>
            <span
              className={`text-xs font-medium transition-transform duration-200 ease-out group-hover:translate-x-1 whitespace-nowrap ${
                isLaureate ? 'text-amber-300' : theme.eyebrowText
              }`}
            >
              Read story
            </span>
          </div>
        </div>
      </div>
    </motion.article>
  );
}
