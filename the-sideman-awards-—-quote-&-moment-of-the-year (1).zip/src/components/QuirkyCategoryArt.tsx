import { AwardCategory } from '../types';

interface QuirkyCategoryArtProps {
  category: AwardCategory;
}

const STROKE_COLORS: Record<AwardCategory, { primary: string; secondary: string; fill: string }> = {
  quote_of_the_year: {
    primary: 'text-blue-600/20',
    secondary: 'text-indigo-500/25',
    fill: 'fill-blue-400/10',
  },
  sideman_of_the_year: {
    primary: 'text-emerald-700/20',
    secondary: 'text-teal-600/25',
    fill: 'fill-emerald-400/10',
  },
  moment_of_the_year: {
    primary: 'text-rose-600/20',
    secondary: 'text-orange-500/25',
    fill: 'fill-rose-400/10',
  },
  funniest_person: {
    primary: 'text-violet-600/20',
    secondary: 'text-purple-500/25',
    fill: 'fill-violet-400/10',
  },
  little_boy_award: {
    primary: 'text-orange-600/20',
    secondary: 'text-amber-500/25',
    fill: 'fill-orange-400/10',
  },
  best_debate: {
    primary: 'text-cyan-700/20',
    secondary: 'text-teal-600/25',
    fill: 'fill-cyan-400/10',
  },
  honorable_mentions: {
    primary: 'text-amber-700/20',
    secondary: 'text-orange-600/25',
    fill: 'fill-amber-400/10',
  },
};

export function QuirkyCategoryArt({ category }: QuirkyCategoryArtProps) {
  const palette = STROKE_COLORS[category];

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 overflow-hidden rounded-3xl select-none"
    >
      {/* Top-right quirky comic speech bubble + squiggle */}
      <svg
        viewBox="0 0 260 220"
        className={`absolute -right-6 top-6 h-52 w-60 rotate-6 ${palette.primary} ${palette.fill}`}
        fill="none"
      >
        <path
          d="M36 42C36 27 48 16 63 16H205C220 16 232 27 232 42V132C232 147 220 158 205 158H116L74 196L82 158H63C48 158 36 147 36 132V42Z"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M78 72C94 58 112 86 128 72C144 58 162 86 178 72"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <circle cx="96" cy="112" r="6" fill="currentColor" />
        <circle cx="134" cy="112" r="6" fill="currentColor" />
        <circle cx="172" cy="112" r="6" fill="currentColor" />
      </svg>

      {/* Left mid quirky crooked trophy & starburst doodles */}
      <svg
        viewBox="0 0 220 260"
        className={`absolute -left-8 top-1/3 h-64 w-56 -rotate-12 ${palette.secondary} ${palette.fill}`}
        fill="none"
      >
        <path
          d="M68 48H152V104C152 128 134 148 110 148C86 148 68 128 68 104V48Z"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinejoin="round"
        />
        <path
          d="M68 62H44C36 62 32 70 34 78C38 94 50 104 68 104"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path
          d="M152 62H176C184 62 188 70 186 78C182 94 170 104 152 104"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path
          d="M110 148V186M82 186H138M72 206H148"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
        />
        <path
          d="M174 174L180 190L196 196L180 202L174 218L168 202L152 196L168 190L174 174Z"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />
      </svg>

      {/* Center-top subtle zigzag & exclamation spark */}
      <svg
        viewBox="0 0 300 120"
        className={`absolute left-1/3 top-10 h-28 w-72 opacity-80 ${palette.primary}`}
        fill="none"
      >
        <path
          d="M20 75L48 45L76 75L104 45L132 75L160 45"
          stroke="currentColor"
          strokeWidth="3"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="212" cy="52" r="14" stroke="currentColor" strokeWidth="3" strokeDasharray="6 6" />
        <path d="M254 24L246 58M244 74V78" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" />
      </svg>

      {/* Bottom-right category-specific quirky doodle */}
      {category === 'quote_of_the_year' && (
        <svg
          viewBox="0 0 240 200"
          className={`absolute bottom-4 right-10 h-44 w-52 rotate-3 ${palette.secondary}`}
          fill="none"
        >
          <path
            d="M44 128C44 92 66 64 98 54L104 72C84 80 74 96 74 114H102V164H44V128ZM134 128C134 92 156 64 188 54L194 72C174 80 164 96 164 114H192V164H134V128Z"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
        </svg>
      )}

      {category === 'sideman_of_the_year' && (
        <svg
          viewBox="0 0 240 200"
          className={`absolute bottom-4 right-10 h-44 w-52 -rotate-6 ${palette.secondary}`}
          fill="none"
        >
          <circle cx="72" cy="82" r="24" stroke="currentColor" strokeWidth="3" />
          <circle cx="144" cy="82" r="24" stroke="currentColor" strokeWidth="3" />
          <path d="M96 82C102 74 114 74 120 82" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          <path d="M62 146C74 166 142 166 154 146" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
        </svg>
      )}

      {category === 'moment_of_the_year' && (
        <svg
          viewBox="0 0 240 200"
          className={`absolute bottom-4 right-10 h-44 w-52 rotate-6 ${palette.secondary}`}
          fill="none"
        >
          <rect x="46" y="72" width="136" height="92" rx="10" stroke="currentColor" strokeWidth="3" />
          <path d="M46 72L174 42L182 64L52 94Z" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />
          <path d="M78 78L94 60M116 70L132 52M152 62L166 44" stroke="currentColor" strokeWidth="3" />
        </svg>
      )}

      {category === 'funniest_person' && (
        <svg
          viewBox="0 0 240 200"
          className={`absolute bottom-4 right-10 h-44 w-52 -rotate-3 ${palette.secondary}`}
          fill="none"
        >
          {/* Laughing comedy face & sound waves */}
          <circle cx="118" cy="100" r="46" stroke="currentColor" strokeWidth="3" />
          <path d="M94 86C100 78 108 78 112 86M126 86C132 78 140 78 144 86" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
          <path d="M94 112C104 134 134 134 144 112Z" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />
          <path d="M174 74C186 86 186 114 174 126M190 62C206 82 206 118 190 138" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
        </svg>
      )}

      {category === 'little_boy_award' && (
        <svg
          viewBox="0 0 240 200"
          className={`absolute bottom-4 right-10 h-44 w-52 rotate-6 ${palette.secondary}`}
          fill="none"
        >
          {/* Quirky crooked paper crown & propeller */}
          <path
            d="M52 138L68 72L102 104L126 56L150 104L184 72L194 138H52Z"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinejoin="round"
          />
          <circle cx="126" cy="42" r="8" stroke="currentColor" strokeWidth="2.5" />
          <path d="M96 158H158" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
        </svg>
      )}

      {category === 'best_debate' && (
        <svg
          viewBox="0 0 240 200"
          className={`absolute bottom-4 right-10 h-44 w-52 -rotate-2 ${palette.secondary}`}
          fill="none"
        >
          {/* Opposing debate lightning bolt & duel bubbles */}
          <rect x="34" y="54" width="70" height="44" rx="10" stroke="currentColor" strokeWidth="3" />
          <rect x="136" y="102" width="70" height="44" rx="10" stroke="currentColor" strokeWidth="3" />
          <path
            d="M128 42L106 96H132L112 158"
            stroke="currentColor"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      )}

      {category === 'honorable_mentions' && (
        <svg
          viewBox="0 0 240 200"
          className={`absolute bottom-4 right-10 h-44 w-52 -rotate-3 ${palette.secondary}`}
          fill="none"
        >
          <circle cx="120" cy="94" r="40" stroke="currentColor" strokeWidth="3" strokeDasharray="8 6" />
          <path d="M98 130L86 184L118 164L120 134M142 130L154 184L122 164L120 134" stroke="currentColor" strokeWidth="3" strokeLinejoin="round" />
          <path d="M98 92L110 76L120 90L130 76L142 92V108H98V92Z" stroke="currentColor" strokeWidth="2.5" strokeLinejoin="round" />
        </svg>
      )}

      {/* Bottom-left dotted constellation */}
      <svg
        viewBox="0 0 180 140"
        className={`absolute bottom-6 left-8 h-32 w-40 ${palette.primary}`}
        fill="none"
      >
        <path
          d="M20 110C48 76 74 96 102 58C124 28 148 54 164 26"
          stroke="currentColor"
          strokeWidth="2.5"
          strokeDasharray="5 7"
          strokeLinecap="round"
        />
        <circle cx="20" cy="110" r="5" fill="currentColor" />
        <circle cx="102" cy="58" r="6" fill="currentColor" />
        <circle cx="164" cy="26" r="5" fill="currentColor" />
      </svg>
    </div>
  );
}
