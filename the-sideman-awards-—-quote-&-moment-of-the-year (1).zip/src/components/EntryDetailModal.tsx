import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Check, Share2, Sparkles, Trophy, X } from 'lucide-react';
import { copyEntryDeepLink } from '../lib/shareEntry';
import { AWARD_CATEGORIES, AwardEntry, CATEGORY_THEMES } from '../types';
import { AwardImage } from './AwardImage';

interface EntryDetailModalProps {
  entry: AwardEntry | null;
  onClose: () => void;
}

export function EntryDetailModal({ entry, onClose }: EntryDetailModalProps) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setCopied(false);
  }, [entry?.id]);

  useEffect(() => {
    if (!copied) return;
    const timer = window.setTimeout(() => setCopied(false), 2000);
    return () => window.clearTimeout(timer);
  }, [copied]);

  useEffect(() => {
    if (!entry) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [entry, onClose]);

  if (!entry) return null;

  const currentEntry = entry;
  const categoryMeta = AWARD_CATEGORIES.find((c) => c.id === currentEntry.category);
  const theme = CATEGORY_THEMES[currentEntry.category];
  const tierLabel =
    currentEntry.tier === 'winner'
      ? 'Official Winner'
      : currentEntry.tier === 'honorable_mention'
        ? 'Honorable Mention'
        : 'Official Nominee';

  async function handleShare() {
    const ok = await copyEntryDeepLink(currentEntry.id, currentEntry.category);
    if (ok) {
      setCopied(true);
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/75 p-4 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="spotlight-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
        className={`relative max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl border bg-[#FBF9F5] shadow-2xl ${theme.bandBorder}`}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close detail view"
          className="absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full bg-stone-900/85 text-white transition-colors duration-150 hover:bg-stone-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-600"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12">
          <div className="md:col-span-5">
            <AwardImage
              src={currentEntry.imageUrl}
              alt={`${currentEntry.nomineeName} — ${currentEntry.title}`}
              fallbackLabel={currentEntry.nomineeName}
              aspectClassName="aspect-[4/3] md:aspect-auto md:h-full"
              isMoment={currentEntry.category === 'moment_of_the_year'}
            />
          </div>

          <div className="flex flex-col justify-between p-6 sm:p-8 md:col-span-7">
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500">
                {currentEntry.tier === 'winner' && (
                  <Trophy className="h-3.5 w-3.5 text-amber-600" />
                )}
                <span className={`font-semibold ${theme.eyebrowText}`}>{tierLabel}</span>
                <span aria-hidden="true">·</span>
                <span>{categoryMeta?.label}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">{currentEntry.year}</span>
              </div>

              <h2
                id="spotlight-title"
                className={`mt-3 font-serif text-3xl font-semibold leading-tight ${theme.headingText}`}
              >
                {currentEntry.title}
              </h2>

              <div className={`mt-4 rounded-xl border px-4 py-3 ${theme.thingBoxLight}`}>
                <div className="flex items-center gap-1.5 text-xs font-semibold">
                  <Sparkles className="h-3.5 w-3.5" />
                  <span className={theme.thingLabelLight}>
                    {currentEntry.nomineeName}’s Thing
                  </span>
                </div>
                <p className="mt-1 text-sm font-medium">
                  {currentEntry.signatureThing || currentEntry.title}
                </p>
              </div>

              <blockquote className="mt-5 border-y border-stone-200 py-5 font-serif text-2xl italic leading-relaxed text-stone-800">
                “{currentEntry.quote}”
              </blockquote>

              {currentEntry.context && (
                <div className="mt-5">
                  <p className="text-xs font-medium text-stone-500">Context & Backstory</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-stone-700">
                    {currentEntry.context}
                  </p>
                </div>
              )}
            </div>

            <div className="mt-8 border-t border-stone-200 pt-5">
              <dl className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <dt className="text-xs text-stone-500">Honoree / Nominee</dt>
                  <dd className="mt-0.5 font-medium text-stone-900">{currentEntry.nomineeName}</dd>
                </div>
                <div>
                  <dt className="text-xs text-stone-500">Source Episode</dt>
                  <dd className="mt-0.5 font-medium text-stone-900">{currentEntry.episode}</dd>
                </div>
              </dl>

              <div className="mt-5 flex items-center justify-end">
                <button
                  type="button"
                  onClick={handleShare}
                  className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-medium transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-700 whitespace-nowrap shrink-0 ${
                    copied
                      ? 'border border-emerald-200 bg-emerald-50 text-emerald-800'
                      : `${theme.ctaBg} text-white ${theme.ctaHover}`
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="h-3.5 w-3.5" />
                      <span>Link Copied to Clipboard</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="h-3.5 w-3.5" />
                      <span>Share Deep Link</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
