import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import express, { NextFunction, Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import type { AwardCategory, AwardEntry, AwardTier } from './src/types.ts';

const PORT = Number(process.env.PORT) || 3000;
const ROOT_DIR = process.cwd();
const DATA_DIR = path.join(ROOT_DIR, 'data');
const DATA_FILE = path.join(DATA_DIR, 'awards.json');
const UPLOADS_DIR = path.join(ROOT_DIR, 'public', 'uploads');

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'sideman2026';
const ADMIN_ACCOUNTS: ReadonlyArray<{ username: string; password: string }> = [
  { username: ADMIN_USERNAME, password: ADMIN_PASSWORD },
  { username: 'ben', password: '12345' },
];
const SESSION_SECRET =
  process.env.SESSION_SECRET ||
  crypto.createHash('sha256').update(`${ADMIN_USERNAME}:${ADMIN_PASSWORD}:sideman-awards`).digest('hex');

const TOKEN_COOKIE_NAME = 'sideman_admin_session';
const TOKEN_TTL_MS = 1000 * 60 * 60 * 12; // 12 hours

const VALID_CATEGORIES: AwardCategory[] = [
  'quote_of_the_year',
  'sideman_of_the_year',
  'moment_of_the_year',
  'funniest_person',
  'little_boy_award',
  'best_debate',
  'honorable_mentions',
];

const VALID_TIERS: AwardTier[] = ['winner', 'nominee', 'honorable_mention'];

const INITIAL_ENTRIES: AwardEntry[] = [
  {
    id: 'qoty-winner-2026',
    category: 'quote_of_the_year',
    tier: 'winner',
    nomineeName: 'Callum Reid',
    signatureThing: 'Turning bad navigation into a philosophical retreat',
    title: 'The 45-Minute Detour Defense',
    quote:
      "I didn't take a wrong turn, I gave everyone forty-five unscheduled minutes to reflect on their life choices.",
    context: 'Delivered with complete sincerity after missing the motorway junction twice in a row.',
    episode: 'Episode 42 · Road Trip Special',
    year: 2026,
    imageUrl: 'preset:portrait-1',
    createdAt: '2026-10-12T18:30:00.000Z',
    updatedAt: '2026-10-12T18:30:00.000Z',
  },
  {
    id: 'qoty-nom-1',
    category: 'quote_of_the_year',
    tier: 'nominee',
    nomineeName: 'Jude Thornton',
    signatureThing: 'Reframing minor fender taps as gentle acoustics',
    title: 'Parallel Parking Philosophy',
    quote:
      'If the bumper taps the curb softly enough, that is technically a whisper, not a collision.',
    context: 'Said immediately after backing into a bollard outside the studio cafe.',
    episode: 'Episode 19 · Morning Commute',
    year: 2026,
    imageUrl: 'preset:portrait-2',
    createdAt: '2026-09-21T14:15:00.000Z',
    updatedAt: '2026-09-21T14:15:00.000Z',
  },
  {
    id: 'qoty-nom-2',
    category: 'quote_of_the_year',
    tier: 'nominee',
    nomineeName: 'Theo Vance',
    signatureThing: 'Deadpan coffee math delivered mid-recording',
    title: 'Espresso Budget Economics',
    quote:
      'It is not an impulse purchase if I have been thinking about it continuously since Tuesday.',
    context: 'Justifying a vintage espresso grinder ordered mid-recording.',
    episode: 'Episode 31 · Late Night Mailbag',
    year: 2026,
    imageUrl: 'preset:portrait-3',
    createdAt: '2026-09-28T20:00:00.000Z',
    updatedAt: '2026-09-28T20:00:00.000Z',
  },
  {
    id: 'qoty-nom-3',
    category: 'quote_of_the_year',
    tier: 'nominee',
    nomineeName: 'Marcus Bell',
    signatureThing: '14-tab spreadsheets with zero actual reservations',
    title: 'The Spreadsheet Alibi',
    quote:
      'I never said I was organized; I said I color-coded the chaos so it looks intentional.',
    context: 'Presented alongside a 14-tab holiday itinerary with zero hotel bookings.',
    episode: 'Episode 36 · Summer Debrief',
    year: 2026,
    imageUrl: 'preset:portrait-1',
    createdAt: '2026-10-02T11:45:00.000Z',
    updatedAt: '2026-10-02T11:45:00.000Z',
  },
  {
    id: 'soty-winner-2026',
    category: 'sideman_of_the_year',
    tier: 'winner',
    nomineeName: 'Jude Thornton',
    signatureThing: '38 consecutive episodes of razor-sharp callbacks',
    title: 'Unmatched Assist Rate All Season',
    quote:
      'Every joke lands twice as hard when someone at the table is already laughing before the punchline arrives.',
    context: 'Recognized for 38 consecutive episodes of razor-sharp callbacks and effortless table chemistry.',
    episode: 'Full 2026 Season · 38 Appearances',
    year: 2026,
    imageUrl: 'preset:portrait-2',
    createdAt: '2026-10-14T16:00:00.000Z',
    updatedAt: '2026-10-14T16:00:00.000Z',
  },
  {
    id: 'soty-nom-1',
    category: 'sideman_of_the_year',
    tier: 'nominee',
    nomineeName: 'Theo Vance',
    signatureThing: 'The single-eyebrow pause and three-word sigh',
    title: 'The Deadpan Anchor',
    quote:
      'You do not need to raise your voice when a three-word sigh destroys an entire five-minute pitch.',
    context: 'Master of the single-eyebrow pause and surgical timing during heated debates.',
    episode: 'Full 2026 Season · 34 Appearances',
    year: 2026,
    imageUrl: 'preset:portrait-3',
    createdAt: '2026-10-05T10:00:00.000Z',
    updatedAt: '2026-10-05T10:00:00.000Z',
  },
  {
    id: 'soty-nom-2',
    category: 'sideman_of_the_year',
    tier: 'nominee',
    nomineeName: 'Callum Reid',
    signatureThing: 'Launching 20-minute debates from innocent questions',
    title: 'Chief Instigator of Tangents',
    quote:
      'Every great twenty-minute debate starts with somebody asking an innocently terrible question.',
    context: 'Turned three routine intro segments into instant archival classics.',
    episode: 'Full 2026 Season · 41 Appearances',
    year: 2026,
    imageUrl: 'preset:portrait-1',
    createdAt: '2026-10-06T12:20:00.000Z',
    updatedAt: '2026-10-06T12:20:00.000Z',
  },
  {
    id: 'moty-winner-2026',
    category: 'moment_of_the_year',
    tier: 'winner',
    nomineeName: 'The Whole Table',
    signatureThing: 'Six minutes of unfiltered warm-up laughter on live mics',
    title: 'The Live Mic Check Confession',
    quote:
      'Wait—are the red lights on? Because I just told the entire story thinking we were still warming up.',
    context: 'Six minutes of uninterrupted table laughter after everyone realized the intro banter was already recording.',
    episode: 'Episode 27 · Uncut Cold Open',
    year: 2026,
    imageUrl: 'preset:moment-1',
    createdAt: '2026-10-15T19:10:00.000Z',
    updatedAt: '2026-10-15T19:10:00.000Z',
  },
  {
    id: 'moty-nom-1',
    category: 'moment_of_the_year',
    tier: 'nominee',
    nomineeName: 'Callum & Theo',
    signatureThing: 'Synchronized full-chest wrong trivia confidence',
    title: 'The Simultaneous Wrong Answer',
    quote:
      'We both said Belgium with full chest confidence and the capital we named is in Austria.',
    context: 'Double-down trivia meltdown that forced a ten-minute pause to recover.',
    episode: 'Episode 14 · Pub Quiz Night',
    year: 2026,
    imageUrl: 'preset:hero',
    createdAt: '2026-09-18T15:30:00.000Z',
    updatedAt: '2026-09-18T15:30:00.000Z',
  },
  {
    id: 'moty-nom-2',
    category: 'moment_of_the_year',
    tier: 'nominee',
    nomineeName: 'Jude Thornton',
    signatureThing: 'Finishing a five-minute story while hitting the floor',
    title: 'The Chair Collapse Mid-Rant',
    quote:
      'Notice how I kept speaking smoothly on the way down—that is broadcast professionalism.',
    context: 'Studio stool gave out at the exact climax of a five-minute story without dropping a syllable.',
    episode: 'Episode 39 · Studio Live',
    year: 2026,
    imageUrl: 'preset:portrait-2',
    createdAt: '2026-10-08T09:40:00.000Z',
    updatedAt: '2026-10-08T09:40:00.000Z',
  },
  {
    id: 'hm-1',
    category: 'honorable_mentions',
    tier: 'honorable_mention',
    nomineeName: 'Theo Vance',
    signatureThing: 'Stubborn zero-umbrella policy in torrential rain',
    title: 'Weather Forecast Skepticism',
    quote: 'Saying there is a 20% chance of rain is just meteorology hedging its bets.',
    context: 'Delivered while refusing to carry an umbrella into a downpour.',
    episode: 'Episode 08 · Rainy Walk',
    year: 2026,
    imageUrl: 'preset:portrait-3',
    createdAt: '2026-08-19T13:00:00.000Z',
    updatedAt: '2026-08-19T13:00:00.000Z',
  },
  {
    id: 'hm-2',
    category: 'honorable_mentions',
    tier: 'honorable_mention',
    nomineeName: 'Callum Reid',
    signatureThing: 'Treating kitchen smoke alarms as standing ovations',
    title: 'Cooking Timer Optionality',
    quote: 'Smoke alarms are basically applause for ambitious seasoning.',
    context: 'Explaining why dinner started forty minutes behind schedule.',
    episode: 'Episode 23 · House Cook-Off',
    year: 2026,
    imageUrl: 'preset:portrait-1',
    createdAt: '2026-09-04T17:45:00.000Z',
    updatedAt: '2026-09-04T17:45:00.000Z',
  },
  {
    id: 'hm-3',
    category: 'honorable_mentions',
    tier: 'honorable_mention',
    nomineeName: 'Jude Thornton',
    signatureThing: '72-hour group chat reply latency',
    title: 'Group Chat Timing',
    quote: 'Replying "sounds good" three days after the event has ended is still moral support.',
    context: 'Defending his 72-hour response latency in the group thread.',
    episode: 'Episode 33 · Inbox Zero',
    year: 2026,
    imageUrl: 'preset:portrait-2',
    createdAt: '2026-09-25T11:10:00.000Z',
    updatedAt: '2026-09-25T11:10:00.000Z',
  },
  {
    id: 'fp-winner-2026',
    category: 'funniest_person',
    tier: 'winner',
    nomineeName: 'Theo Vance',
    signatureThing: 'Effortless deadpan escalation mid-story',
    title: 'Zero-Smile Room Destroyer',
    quote:
      'I was trying to keep a straight face, which somehow made everyone else laugh for four straight minutes.',
    context: 'Voted funniest presence across 34 appearances for razor-dry comedic timing.',
    episode: 'Full 2026 Season · Comedy MVP',
    year: 2026,
    imageUrl: 'preset:portrait-3',
    createdAt: '2026-10-16T14:00:00.000Z',
    updatedAt: '2026-10-16T14:00:00.000Z',
  },
  {
    id: 'fp-nom-1',
    category: 'funniest_person',
    tier: 'nominee',
    nomineeName: 'Jude Thornton',
    signatureThing: 'Instant physical impressions and contagious wheeze-laugh',
    title: 'The Table Catalyst',
    quote:
      'Half the time I am not even telling the joke—I am just reacting loudly enough to set everyone else off.',
    context: 'Turned throwaway asides into the highest-replayed clips of the season.',
    episode: 'Episode 29 · Late Night Chaos',
    year: 2026,
    imageUrl: 'preset:portrait-2',
    createdAt: '2026-10-03T18:20:00.000Z',
    updatedAt: '2026-10-03T18:20:00.000Z',
  },
  {
    id: 'fp-nom-2',
    category: 'funniest_person',
    tier: 'nominee',
    nomineeName: 'Callum Reid',
    signatureThing: 'Shameless storytelling with zero filter',
    title: 'The Unintentional Stand-Up',
    quote:
      'If I tell a story accurately and you think it is a bit, that is between you and reality.',
    context: 'Delivered three completely true vacation stories that sounded scripted.',
    episode: 'Episode 40 · Holiday Recap',
    year: 2026,
    imageUrl: 'preset:portrait-1',
    createdAt: '2026-10-07T15:10:00.000Z',
    updatedAt: '2026-10-07T15:10:00.000Z',
  },
  {
    id: 'lba-winner-2026',
    category: 'little_boy_award',
    tier: 'winner',
    nomineeName: 'Marcus Bell',
    signatureThing: 'Packing up the board game when losing by two points',
    title: 'The Monopoly Rulebook Standoff',
    quote:
      'If Free Parking does not pay out taxes, then frankly this entire living room has lost its soul.',
    context: 'Refused to roll the dice for twelve minutes until house rules were amended.',
    episode: 'Episode 22 · Game Night',
    year: 2026,
    imageUrl: 'preset:portrait-1',
    createdAt: '2026-10-17T12:00:00.000Z',
    updatedAt: '2026-10-17T12:00:00.000Z',
  },
  {
    id: 'lba-nom-1',
    category: 'little_boy_award',
    tier: 'nominee',
    nomineeName: 'Callum Reid',
    signatureThing: 'Sulking silently when someone takes the last hash brown',
    title: 'The Breakfast Tray Protest',
    quote:
      'I am not mad, I just think we should pause the podcast until the hash brown distribution is audited.',
    context: 'Crossed his arms for an entire twenty-minute segment over brunch leftovers.',
    episode: 'Episode 11 · Sunday Brunch',
    year: 2026,
    imageUrl: 'preset:portrait-2',
    createdAt: '2026-09-10T10:30:00.000Z',
    updatedAt: '2026-09-10T10:30:00.000Z',
  },
  {
    id: 'lba-nom-2',
    category: 'little_boy_award',
    tier: 'nominee',
    nomineeName: 'Theo Vance',
    signatureThing: 'Demanding a controller swap after conceding one goal',
    title: 'Stick Drift Blame Shift',
    quote:
      'My left thumbstick definitely pulled east on that penalty—nobody loses cleanly on this sofa.',
    context: 'Insisted on testing three different controllers before accepting defeat.',
    episode: 'Episode 34 · Couch Tournament',
    year: 2026,
    imageUrl: 'preset:portrait-3',
    createdAt: '2026-09-30T19:45:00.000Z',
    updatedAt: '2026-09-30T19:45:00.000Z',
  },
  {
    id: 'bd-winner-2026',
    category: 'best_debate',
    tier: 'winner',
    nomineeName: 'Callum vs. Theo',
    signatureThing: '25-minute war over whether cereal counts as cold soup',
    title: 'The Cereal Is Soup Trial',
    quote:
      'Milk is literally a dairy broth and spoons are involved—stop running from basic culinary geometry.',
    context: 'Ended with a whiteboard diagram, three polls, and zero minds changed.',
    episode: 'Episode 30 · Kitchen Court',
    year: 2026,
    imageUrl: 'preset:moment-1',
    createdAt: '2026-10-18T17:15:00.000Z',
    updatedAt: '2026-10-18T17:15:00.000Z',
  },
  {
    id: 'bd-nom-1',
    category: 'best_debate',
    tier: 'nominee',
    nomineeName: 'Jude vs. Marcus',
    signatureThing: 'Debating how early is "too early" to arrive at the airport',
    title: 'Four Hours Early vs. Boarding Call',
    quote:
      'If I am not eating a lukewarm croissant at Gate 12 three hours early, I am practically missing the flight.',
    context: 'Clashed passionately over airport arrival buffers ahead of the group trip.',
    episode: 'Episode 17 · Departure Lounge',
    year: 2026,
    imageUrl: 'preset:hero',
    createdAt: '2026-09-14T11:20:00.000Z',
    updatedAt: '2026-09-14T11:20:00.000Z',
  },
  {
    id: 'bd-nom-2',
    category: 'best_debate',
    tier: 'nominee',
    nomineeName: 'The Whole Table',
    signatureThing: 'Does a straw have one hole or two holes?',
    title: 'Topological Straw Crisis',
    quote:
      'It is one continuous tunnel—if you dig through a mountain you do not tell commuters there are two tunnels.',
    context: 'Derailing the entire episode intro for eighteen uninterrupted minutes.',
    episode: 'Episode 41 · Late Night Philosophy',
    year: 2026,
    imageUrl: 'preset:moment-1',
    createdAt: '2026-10-09T21:00:00.000Z',
    updatedAt: '2026-10-09T21:00:00.000Z',
  },
];

async function ensureStorage(): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.mkdir(UPLOADS_DIR, { recursive: true });
  try {
    await fs.access(DATA_FILE);
    const raw = await fs.readFile(DATA_FILE, 'utf8');
    const existing = JSON.parse(raw);
    if (Array.isArray(existing)) {
      const existingIds = new Set(existing.map((item) => item?.id));
      const newCategorySeeds = INITIAL_ENTRIES.filter(
        (seed) =>
          (seed.category === 'funniest_person' ||
            seed.category === 'little_boy_award' ||
            seed.category === 'best_debate') &&
          !existingIds.has(seed.id) &&
          !existing.some((item) => item?.category === seed.category)
      );
      if (newCategorySeeds.length > 0) {
        const merged = [...existing, ...newCategorySeeds];
        await fs.writeFile(DATA_FILE, JSON.stringify(merged, null, 2), 'utf8');
      }
    }
  } catch {
    await fs.writeFile(DATA_FILE, JSON.stringify(INITIAL_ENTRIES, null, 2), 'utf8');
  }
}

async function readEntries(): Promise<AwardEntry[]> {
  await ensureStorage();
  const raw = await fs.readFile(DATA_FILE, 'utf8');
  const parsed = JSON.parse(raw);
  if (!Array.isArray(parsed)) return [];
  const defaultById = new Map(INITIAL_ENTRIES.map((e) => [e.id, e]));
  return parsed.map((item) => {
    const fallbackThing = defaultById.get(item.id)?.signatureThing || item.title || '';
    return {
      ...item,
      signatureThing:
        typeof item.signatureThing === 'string' && item.signatureThing.trim()
          ? item.signatureThing
          : fallbackThing,
    };
  });
}

async function writeEntries(entries: AwardEntry[]): Promise<void> {
  await ensureStorage();
  const tmpFile = `${DATA_FILE}.tmp`;
  await fs.writeFile(tmpFile, JSON.stringify(entries, null, 2), 'utf8');
  await fs.rename(tmpFile, DATA_FILE);
}

function safeEqual(a: string, b: string): boolean {
  const hashA = crypto.createHash('sha256').update(a).digest();
  const hashB = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(hashA, hashB);
}

function signToken(username: string): string {
  const payload = {
    sub: username,
    exp: Date.now() + TOKEN_TTL_MS,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(encoded).digest('base64url');
  return `${encoded}.${sig}`;
}

function verifyToken(token: string | undefined): { valid: boolean; username?: string } {
  if (!token || !token.includes('.')) return { valid: false };
  const [encoded, sig] = token.split('.');
  if (!encoded || !sig) return { valid: false };
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  if (!safeEqual(sig, expectedSig)) return { valid: false };
  try {
    const payload = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
    if (!payload?.sub || typeof payload.exp !== 'number' || Date.now() > payload.exp) {
      return { valid: false };
    }
    return { valid: true, username: String(payload.sub) };
  } catch {
    return { valid: false };
  }
}

function parseCookies(cookieHeader?: string): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const val = decodeURIComponent(part.slice(idx + 1).trim());
    result[key] = val;
  }
  return result;
}

function extractToken(req: Request): string | undefined {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const cookies = parseCookies(req.headers.cookie);
  return cookies[TOKEN_COOKIE_NAME];
}

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const token = extractToken(req);
  const check = verifyToken(token);
  if (!check.valid) {
    res.status(401).json({ error: 'Unauthorized. Please sign in as admin.' });
    return;
  }
  next();
}

function sanitizeEntryInput(body: Record<string, unknown>): {
  ok: true;
  data: Omit<AwardEntry, 'id' | 'createdAt' | 'updatedAt'>;
} | {
  ok: false;
  error: string;
} {
  const category = String(body.category || '') as AwardCategory;
  let tier = String(body.tier || '') as AwardTier;
  const nomineeName = String(body.nomineeName || '').trim().slice(0, 100);
  const signatureThing = String(body.signatureThing || '').trim().slice(0, 140);
  const quote = String(body.quote || '').trim().slice(0, 500);
  const title = String(body.title || '').trim().slice(0, 120);
  const context = String(body.context || '').trim().slice(0, 320);
  const episode = String(body.episode || '').trim().slice(0, 100);
  const yearNum = Number(body.year) || new Date().getFullYear();
  const imageUrl = String(body.imageUrl || '').trim().slice(0, 1000);

  if (!VALID_CATEGORIES.includes(category)) {
    return { ok: false, error: 'Invalid award category.' };
  }
  if (category === 'honorable_mentions') {
    tier = 'honorable_mention';
  } else if (!VALID_TIERS.includes(tier) || tier === 'honorable_mention') {
    tier = tier === 'winner' ? 'winner' : 'nominee';
  }
  if (!nomineeName) {
    return { ok: false, error: 'Nominee name is required.' };
  }
  if (!quote) {
    return { ok: false, error: 'Quote or highlight text is required.' };
  }

  const resolvedTitle = title || `${nomineeName} Highlight`;

  return {
    ok: true,
    data: {
      category,
      tier,
      nomineeName,
      signatureThing: signatureThing || resolvedTitle,
      quote,
      title: resolvedTitle,
      context,
      episode: episode || `${yearNum} Season`,
      year: Math.min(2100, Math.max(2000, Math.round(yearNum))),
      imageUrl,
    },
  };
}

async function startServer() {
  await ensureStorage();

  const app = express();
  app.use(express.json({ limit: '10mb' }));
  app.use('/uploads', express.static(UPLOADS_DIR));

  // Public: list all entries
  app.get('/api/entries', async (_req: Request, res: Response) => {
    try {
      const entries = await readEntries();
      res.json({ entries });
    } catch (error) {
      console.error('Failed to read entries:', error);
      res.status(500).json({ error: 'Unable to load award entries.' });
    }
  });

  // Auth: login
  app.post('/api/auth/login', (req: Request, res: Response) => {
    const username = String(req.body?.username || '').trim();
    const password = String(req.body?.password || '');

    const isValidAdmin = ADMIN_ACCOUNTS.some(
      (account) => safeEqual(username, account.username) && safeEqual(password, account.password)
    );

    if (!isValidAdmin) {
      res.status(401).json({ error: 'Invalid username or password.' });
      return;
    }

    const token = signToken(username);
    res.cookie(TOKEN_COOKIE_NAME, token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: TOKEN_TTL_MS,
      path: '/',
    });
    res.json({ authenticated: true, username, token });
  });

  // Auth: check session
  app.get('/api/auth/session', (req: Request, res: Response) => {
    const check = verifyToken(extractToken(req));
    res.json({ authenticated: check.valid, username: check.username || null });
  });

  // Auth: logout
  app.post('/api/auth/logout', (_req: Request, res: Response) => {
    res.clearCookie(TOKEN_COOKIE_NAME, { path: '/' });
    res.json({ ok: true });
  });

  // Admin: upload nominee photo (base64 data URL)
  app.post('/api/upload', requireAdmin, async (req: Request, res: Response) => {
    try {
      const dataUrl = String(req.body?.dataUrl || '');
      const match = dataUrl.match(/^data:image\/(png|jpeg|jpg|webp|gif);base64,([A-Za-z0-9+/=]+)$/);
      if (!match) {
        res.status(400).json({ error: 'Invalid image format. Please upload PNG, JPG, WEBP, or GIF.' });
        return;
      }
      const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
      const buffer = Buffer.from(match[2], 'base64');
      if (buffer.byteLength > 5 * 1024 * 1024) {
        res.status(400).json({ error: 'Image must be smaller than 5 MB.' });
        return;
      }
      const fileName = `nominee_${Date.now()}_${crypto.randomUUID().slice(0, 8)}.${ext}`;
      await fs.writeFile(path.join(UPLOADS_DIR, fileName), buffer);
      res.status(201).json({ url: `/uploads/${fileName}` });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ error: 'Failed to save uploaded image.' });
    }
  });

  // Admin: create entry
  app.post('/api/entries', requireAdmin, async (req: Request, res: Response) => {
    const parsed = sanitizeEntryInput(req.body || {});
    if (!parsed.ok) {
      res.status(400).json({ error: parsed.error });
      return;
    }

    const now = new Date().toISOString();
    const newEntry: AwardEntry = {
      id: `${parsed.data.category}-${crypto.randomUUID().slice(0, 8)}`,
      ...parsed.data,
      createdAt: now,
      updatedAt: now,
    };

    const entries = await readEntries();
    // Keep one active winner per category if desired when creating a new winner
    const updated = entries.map((item) => {
      if (
        newEntry.tier === 'winner' &&
        item.category === newEntry.category &&
        item.tier === 'winner'
      ) {
        return { ...item, tier: 'nominee' as AwardTier, updatedAt: now };
      }
      return item;
    });
    updated.unshift(newEntry);
    await writeEntries(updated);
    res.status(201).json({ entry: newEntry, entries: updated });
  });

  // Admin: bulk create unlimited nominees for a category via JSON array
  app.post('/api/entries/bulk', requireAdmin, async (req: Request, res: Response) => {
    const rawItems = Array.isArray(req.body?.items) ? req.body.items : null;
    if (!rawItems || rawItems.length === 0) {
      res.status(400).json({ error: 'Provide a non-empty array of nominee entries.' });
      return;
    }

    const now = new Date().toISOString();
    const created: AwardEntry[] = [];

    for (let i = 0; i < rawItems.length; i += 1) {
      const parsed = sanitizeEntryInput(rawItems[i] || {});
      if (!parsed.ok) {
        res.status(400).json({ error: `Item #${i + 1}: ${parsed.error}` });
        return;
      }
      created.push({
        id: `${parsed.data.category}-${crypto.randomUUID().slice(0, 8)}`,
        ...parsed.data,
        createdAt: now,
        updatedAt: now,
      });
    }

    const entries = await readEntries();
    const winningCategories = new Set(
      created.filter((c) => c.tier === 'winner').map((c) => c.category)
    );

    const existingUpdated = entries.map((item) => {
      if (item.tier === 'winner' && winningCategories.has(item.category)) {
        return { ...item, tier: 'nominee' as AwardTier, updatedAt: now };
      }
      return item;
    });

    const merged = [...created, ...existingUpdated];
    await writeEntries(merged);
    res.status(201).json({ addedCount: created.length, entries: merged });
  });

  // Admin: update entry
  app.put('/api/entries/:id', requireAdmin, async (req: Request, res: Response) => {
    const entryId = String(req.params.id || '');
    const parsed = sanitizeEntryInput(req.body || {});
    if (!parsed.ok) {
      res.status(400).json({ error: parsed.error });
      return;
    }

    const entries = await readEntries();
    const targetIdx = entries.findIndex((e) => e.id === entryId);
    if (targetIdx === -1) {
      res.status(404).json({ error: 'Entry not found.' });
      return;
    }

    const now = new Date().toISOString();
    const nextEntries = entries.map((item) => {
      if (item.id === entryId) {
        return {
          ...item,
          ...parsed.data,
          updatedAt: now,
        };
      }
      if (
        parsed.data.tier === 'winner' &&
        item.category === parsed.data.category &&
        item.tier === 'winner'
      ) {
        return { ...item, tier: 'nominee' as AwardTier, updatedAt: now };
      }
      return item;
    });

    await writeEntries(nextEntries);
    res.json({ entry: nextEntries[targetIdx], entries: nextEntries });
  });

  // Admin: quick promote nominee to winner for its category
  app.post('/api/entries/:id/promote', requireAdmin, async (req: Request, res: Response) => {
    const entryId = String(req.params.id || '');
    const entries = await readEntries();
    const target = entries.find((e) => e.id === entryId);
    if (!target) {
      res.status(404).json({ error: 'Entry not found.' });
      return;
    }
    if (target.category === 'honorable_mentions') {
      res.status(400).json({ error: 'Honorable mentions do not have a winner tier.' });
      return;
    }

    const now = new Date().toISOString();
    const nextEntries = entries.map((item) => {
      if (item.id === entryId) {
        return { ...item, tier: 'winner' as AwardTier, updatedAt: now };
      }
      if (item.category === target.category && item.tier === 'winner') {
        return { ...item, tier: 'nominee' as AwardTier, updatedAt: now };
      }
      return item;
    });

    await writeEntries(nextEntries);
    res.json({ entries: nextEntries });
  });

  // Admin: delete entry
  app.delete('/api/entries/:id', requireAdmin, async (req: Request, res: Response) => {
    const entryId = String(req.params.id || '');
    const entries = await readEntries();
    const filtered = entries.filter((e) => e.id !== entryId);
    if (filtered.length === entries.length) {
      res.status(404).json({ error: 'Entry not found.' });
      return;
    }
    await writeEntries(filtered);
    res.json({ entries: filtered });
  });

  // Vite middleware in development, static dist in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(ROOT_DIR, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`The Sideman Awards server running on http://localhost:${PORT}`);
  });
}

startServer();
